var NS_INT_10_G6_JSON = {

	starAnimJson : {"frames": [

		{
			"filename": "Symbol 10 copy instance 10000",
			"frame": {"x":0,"y":0,"w":33,"h":116},
			"rotated": false,
			"trimmed": false,
			"spriteSourceSize": {"x":0,"y":0,"w":33,"h":116},
			"sourceSize": {"w":33,"h":116}
		}
		,{
			"filename": "Symbol 10 copy instance 10001",
			"frame": {"x":0,"y":116,"w":33,"h":116},
			"rotated": false,
			"trimmed": false,
			"spriteSourceSize": {"x":0,"y":0,"w":33,"h":116},
			"sourceSize": {"w":33,"h":116}
		}
		,{
			"filename": "Symbol 10 copy instance 10002",
			"frame": {"x":0,"y":232,"w":33,"h":116},
			"rotated": false,
			"trimmed": false,
			"spriteSourceSize": {"x":0,"y":0,"w":33,"h":116},
			"sourceSize": {"w":33,"h":116}
		}
		,{
			"filename": "Symbol 10 copy instance 10003",
			"frame": {"x":0,"y":348,"w":33,"h":116},
			"rotated": false,
			"trimmed": false,
			"spriteSourceSize": {"x":0,"y":0,"w":33,"h":116},
			"sourceSize": {"w":33,"h":116}
		}
		,{
			"filename": "Symbol 10 copy instance 10004",
			"frame": {"x":33,"y":0,"w":33,"h":116},
			"rotated": false,
			"trimmed": false,
			"spriteSourceSize": {"x":0,"y":0,"w":33,"h":116},
			"sourceSize": {"w":33,"h":116}
		}
		,{
			"filename": "Symbol 10 copy instance 10005",
			"frame": {"x":33,"y":116,"w":33,"h":116},
			"rotated": false,
			"trimmed": false,
			"spriteSourceSize": {"x":0,"y":0,"w":33,"h":116},
			"sourceSize": {"w":33,"h":116}
		}
		,{
			"filename": "Symbol 10 copy instance 10006",
			"frame": {"x":33,"y":232,"w":33,"h":116},
			"rotated": false,
			"trimmed": false,
			"spriteSourceSize": {"x":0,"y":0,"w":33,"h":116},
			"sourceSize": {"w":33,"h":116}
		}
		,{
			"filename": "Symbol 10 copy instance 10007",
			"frame": {"x":33,"y":348,"w":33,"h":116},
			"rotated": false,
			"trimmed": false,
			"spriteSourceSize": {"x":0,"y":0,"w":33,"h":116},
			"sourceSize": {"w":33,"h":116}
		}
		,{
			"filename": "Symbol 10 copy instance 10008",
			"frame": {"x":66,"y":0,"w":33,"h":116},
			"rotated": false,
			"trimmed": false,
			"spriteSourceSize": {"x":0,"y":0,"w":33,"h":116},
			"sourceSize": {"w":33,"h":116}
		}
		,{
			"filename": "Symbol 10 copy instance 10009",
			"frame": {"x":66,"y":116,"w":33,"h":116},
			"rotated": false,
			"trimmed": false,
			"spriteSourceSize": {"x":0,"y":0,"w":33,"h":116},
			"sourceSize": {"w":33,"h":116}
		}
		,{
			"filename": "Symbol 10 copy instance 10010",
			"frame": {"x":66,"y":232,"w":33,"h":116},
			"rotated": false,
			"trimmed": false,
			"spriteSourceSize": {"x":0,"y":0,"w":33,"h":116},
			"sourceSize": {"w":33,"h":116}
		}
		,{
			"filename": "Symbol 10 copy instance 10011",
			"frame": {"x":66,"y":348,"w":33,"h":116},
			"rotated": false,
			"trimmed": false,
			"spriteSourceSize": {"x":0,"y":0,"w":33,"h":116},
			"sourceSize": {"w":33,"h":116}
		}
		,{
			"filename": "Symbol 10 copy instance 10012",
			"frame": {"x":99,"y":0,"w":33,"h":116},
			"rotated": false,
			"trimmed": false,
			"spriteSourceSize": {"x":0,"y":0,"w":33,"h":116},
			"sourceSize": {"w":33,"h":116}
		}
		,{
			"filename": "Symbol 10 copy instance 10013",
			"frame": {"x":99,"y":116,"w":33,"h":116},
			"rotated": false,
			"trimmed": false,
			"spriteSourceSize": {"x":0,"y":0,"w":33,"h":116},
			"sourceSize": {"w":33,"h":116}
		}
		,{
			"filename": "Symbol 10 copy instance 10014",
			"frame": {"x":99,"y":232,"w":33,"h":116},
			"rotated": false,
			"trimmed": false,
			"spriteSourceSize": {"x":0,"y":0,"w":33,"h":116},
			"sourceSize": {"w":33,"h":116}
		}
		,{
			"filename": "Symbol 10 copy instance 10015",
			"frame": {"x":99,"y":348,"w":33,"h":116},
			"rotated": false,
			"trimmed": false,
			"spriteSourceSize": {"x":0,"y":0,"w":33,"h":116},
			"sourceSize": {"w":33,"h":116}
		}
		,{
			"filename": "Symbol 10 copy instance 10016",
			"frame": {"x":132,"y":0,"w":33,"h":116},
			"rotated": false,
			"trimmed": false,
			"spriteSourceSize": {"x":0,"y":0,"w":33,"h":116},
			"sourceSize": {"w":33,"h":116}
		}
		,{
			"filename": "Symbol 10 copy instance 10017",
			"frame": {"x":132,"y":116,"w":33,"h":116},
			"rotated": false,
			"trimmed": false,
			"spriteSourceSize": {"x":0,"y":0,"w":33,"h":116},
			"sourceSize": {"w":33,"h":116}
		}
		,{
			"filename": "Symbol 10 copy instance 10018",
			"frame": {"x":132,"y":232,"w":33,"h":116},
			"rotated": false,
			"trimmed": false,
			"spriteSourceSize": {"x":0,"y":0,"w":33,"h":116},
			"sourceSize": {"w":33,"h":116}
		}
		,{
			"filename": "Symbol 10 copy instance 10019",
			"frame": {"x":132,"y":348,"w":33,"h":116},
			"rotated": false,
			"trimmed": false,
			"spriteSourceSize": {"x":0,"y":0,"w":33,"h":116},
			"sourceSize": {"w":33,"h":116}
		}
		,{
			"filename": "Symbol 10 copy instance 10020",
			"frame": {"x":165,"y":0,"w":33,"h":116},
			"rotated": false,
			"trimmed": false,
			"spriteSourceSize": {"x":0,"y":0,"w":33,"h":116},
			"sourceSize": {"w":33,"h":116}
		}
		,{
			"filename": "Symbol 10 copy instance 10021",
			"frame": {"x":165,"y":116,"w":33,"h":116},
			"rotated": false,
			"trimmed": false,
			"spriteSourceSize": {"x":0,"y":0,"w":33,"h":116},
			"sourceSize": {"w":33,"h":116}
		}
		,{
			"filename": "Symbol 10 copy instance 10022",
			"frame": {"x":165,"y":232,"w":33,"h":116},
			"rotated": false,
			"trimmed": false,
			"spriteSourceSize": {"x":0,"y":0,"w":33,"h":116},
			"sourceSize": {"w":33,"h":116}
		}
		,{
			"filename": "Symbol 10 copy instance 10023",
			"frame": {"x":165,"y":348,"w":33,"h":116},
			"rotated": false,
			"trimmed": false,
			"spriteSourceSize": {"x":0,"y":0,"w":33,"h":116},
			"sourceSize": {"w":33,"h":116}
		}
		,{
			"filename": "Symbol 10 copy instance 10024",
			"frame": {"x":198,"y":0,"w":33,"h":116},
			"rotated": false,
			"trimmed": false,
			"spriteSourceSize": {"x":0,"y":0,"w":33,"h":116},
			"sourceSize": {"w":33,"h":116}
		}
		,{
			"filename": "Symbol 10 copy instance 10025",
			"frame": {"x":198,"y":116,"w":33,"h":116},
			"rotated": false,
			"trimmed": false,
			"spriteSourceSize": {"x":0,"y":0,"w":33,"h":116},
			"sourceSize": {"w":33,"h":116}
		}
		,{
			"filename": "Symbol 10 copy instance 10026",
			"frame": {"x":198,"y":232,"w":33,"h":116},
			"rotated": false,
			"trimmed": false,
			"spriteSourceSize": {"x":0,"y":0,"w":33,"h":116},
			"sourceSize": {"w":33,"h":116}
		}
		,{
			"filename": "Symbol 10 copy instance 10027",
			"frame": {"x":198,"y":348,"w":33,"h":116},
			"rotated": false,
			"trimmed": false,
			"spriteSourceSize": {"x":0,"y":0,"w":33,"h":116},
			"sourceSize": {"w":33,"h":116}
		}
		,{
			"filename": "Symbol 10 copy instance 10028",
			"frame": {"x":231,"y":0,"w":33,"h":116},
			"rotated": false,
			"trimmed": false,
			"spriteSourceSize": {"x":0,"y":0,"w":33,"h":116},
			"sourceSize": {"w":33,"h":116}
		}
		,{
			"filename": "Symbol 10 copy instance 10029",
			"frame": {"x":231,"y":116,"w":33,"h":116},
			"rotated": false,
			"trimmed": false,
			"spriteSourceSize": {"x":0,"y":0,"w":33,"h":116},
			"sourceSize": {"w":33,"h":116}
		}
		,{
			"filename": "Symbol 10 copy instance 10030",
			"frame": {"x":231,"y":232,"w":33,"h":116},
			"rotated": false,
			"trimmed": false,
			"spriteSourceSize": {"x":0,"y":0,"w":33,"h":116},
			"sourceSize": {"w":33,"h":116}
		}
		,{
			"filename": "Symbol 10 copy instance 10031",
			"frame": {"x":231,"y":348,"w":33,"h":116},
			"rotated": false,
			"trimmed": false,
			"spriteSourceSize": {"x":0,"y":0,"w":33,"h":116},
			"sourceSize": {"w":33,"h":116}
		}
		,{
			"filename": "Symbol 10 copy instance 10032",
			"frame": {"x":264,"y":0,"w":33,"h":116},
			"rotated": false,
			"trimmed": false,
			"spriteSourceSize": {"x":0,"y":0,"w":33,"h":116},
			"sourceSize": {"w":33,"h":116}
		}
		,{
			"filename": "Symbol 10 copy instance 10033",
			"frame": {"x":264,"y":116,"w":33,"h":116},
			"rotated": false,
			"trimmed": false,
			"spriteSourceSize": {"x":0,"y":0,"w":33,"h":116},
			"sourceSize": {"w":33,"h":116}
		}
		,{
			"filename": "Symbol 10 copy instance 10034",
			"frame": {"x":264,"y":232,"w":33,"h":116},
			"rotated": false,
			"trimmed": false,
			"spriteSourceSize": {"x":0,"y":0,"w":33,"h":116},
			"sourceSize": {"w":33,"h":116}
		}
		,{
			"filename": "Symbol 10 copy instance 10035",
			"frame": {"x":264,"y":348,"w":33,"h":116},
			"rotated": false,
			"trimmed": false,
			"spriteSourceSize": {"x":0,"y":0,"w":33,"h":116},
			"sourceSize": {"w":33,"h":116}
		}],
		"meta": {
			"app": "Adobe Animate",
			"version": "15.1.0.210",
			"image": "st.png",
			"format": "RGB8",
			"size": {"w":334,"h":479},
			"scale": "1"
		}
		},
	speakerJson : {"frames": [

		{
			"filename": "Symbol 5 instance 10000",
			"frame": {"x":0,"y":0,"w":41,"h":30},
			"rotated": false,
			"trimmed": false,
			"spriteSourceSize": {"x":0,"y":0,"w":41,"h":30},
			"sourceSize": {"w":41,"h":30}
		},
		{
			"filename": "Symbol 5 instance 10001",
			"frame": {"x":0,"y":30,"w":41,"h":30},
			"rotated": false,
			"trimmed": false,
			"spriteSourceSize": {"x":0,"y":0,"w":41,"h":30},
			"sourceSize": {"w":41,"h":30}
		}],
		"meta": {
			"app": "Adobe Animate",
			"version": "15.1.0.210",
			"image": "s.png",
			"format": "RGB8",
			"size": {"w":44,"h":64},
			"scale": "1"
		}
	},

	btnJson : {"frames": [

{
	"filename": "Symbol 1 instance 10000",
	"frame": {"x":0,"y":0,"w":212,"h":71},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":212,"h":71},
	"sourceSize": {"w":212,"h":71}
}
,{
	"filename": "Symbol 1 instance 10001",
	"frame": {"x":0,"y":71,"w":212,"h":71},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":212,"h":71},
	"sourceSize": {"w":212,"h":71}
}],
"meta": {
	"app": "Adobe Animate",
	"version": "16.5.1.104",
	"image": "b1.png",
	"format": "RGB8",
	"size": {"w":213,"h":144},
	"scale": "1"
}
},

	replyJson : {"frames": [

{
	"filename": "Symbol 8 instance 10000",
	"frame": {"x":0,"y":0,"w":47,"h":47},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":47,"h":47},
	"sourceSize": {"w":47,"h":47}
}
,{
	"filename": "Symbol 8 instance 10001",
	"frame": {"x":47,"y":0,"w":47,"h":47},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":47,"h":47},
	"sourceSize": {"w":47,"h":47}
}
,{
	"filename": "Symbol 8 instance 10002",
	"frame": {"x":0,"y":0,"w":47,"h":47},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":47,"h":47},
	"sourceSize": {"w":47,"h":47}
}],
"meta": {
	"app": "Adobe Animate",
	"version": "15.1.0.210",
	"image": "Back btn.png",
	"format": "RGBA8888",
	"size": {"w":98,"h":48},
	"scale": "1"
}
},

    backbtnJson : {"frames": [

		{
			"filename": "Symbol 9 instance 10000",
			"frame": {"x":0,"y":0,"w":41,"h":29},
			"rotated": false,
			"trimmed": false,
			"spriteSourceSize": {"x":0,"y":0,"w":41,"h":29},
			"sourceSize": {"w":41,"h":29}
		}
		,{
			"filename": "Symbol 9 instance 10001",
			"frame": {"x":0,"y":29,"w":41,"h":29},
			"rotated": false,
			"trimmed": false,
			"spriteSourceSize": {"x":0,"y":0,"w":41,"h":29},
			"sourceSize": {"w":41,"h":29}
		}],
		"meta": {
			"app": "Adobe Animate",
			"version": "15.1.0.210",
			"image": "back.png",
			"format": "RGB8",
			"size": {"w":44,"h":64},
			"scale": "1"
		}
		},

    cater_HappyJson : {"frames": [

{
	"filename": "Symbol 1 instance 10000",
	"frame": {"x":0,"y":0,"w":239,"h":297},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":239,"h":297},
	"sourceSize": {"w":239,"h":297}
}
,{
	"filename": "Symbol 1 instance 10001",
	"frame": {"x":239,"y":0,"w":239,"h":297},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":239,"h":297},
	"sourceSize": {"w":239,"h":297}
}
,{
	"filename": "Symbol 1 instance 10002",
	"frame": {"x":478,"y":0,"w":239,"h":297},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":239,"h":297},
	"sourceSize": {"w":239,"h":297}
}
,{
	"filename": "Symbol 1 instance 10003",
	"frame": {"x":717,"y":0,"w":239,"h":297},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":239,"h":297},
	"sourceSize": {"w":239,"h":297}
}
,{
	"filename": "Symbol 1 instance 10004",
	"frame": {"x":956,"y":0,"w":239,"h":297},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":239,"h":297},
	"sourceSize": {"w":239,"h":297}
}
,{
	"filename": "Symbol 1 instance 10005",
	"frame": {"x":1195,"y":0,"w":239,"h":297},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":239,"h":297},
	"sourceSize": {"w":239,"h":297}
}
,{
	"filename": "Symbol 1 instance 10006",
	"frame": {"x":1434,"y":0,"w":239,"h":297},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":239,"h":297},
	"sourceSize": {"w":239,"h":297}
}
,{
	"filename": "Symbol 1 instance 10007",
	"frame": {"x":1673,"y":0,"w":239,"h":297},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":239,"h":297},
	"sourceSize": {"w":239,"h":297}
}
,{
	"filename": "Symbol 1 instance 10008",
	"frame": {"x":0,"y":297,"w":239,"h":297},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":239,"h":297},
	"sourceSize": {"w":239,"h":297}
}
,{
	"filename": "Symbol 1 instance 10009",
	"frame": {"x":239,"y":297,"w":239,"h":297},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":239,"h":297},
	"sourceSize": {"w":239,"h":297}
}
,{
	"filename": "Symbol 1 instance 10010",
	"frame": {"x":478,"y":297,"w":239,"h":297},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":239,"h":297},
	"sourceSize": {"w":239,"h":297}
}
,{
	"filename": "Symbol 1 instance 10011",
	"frame": {"x":717,"y":297,"w":239,"h":297},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":239,"h":297},
	"sourceSize": {"w":239,"h":297}
}
,{
	"filename": "Symbol 1 instance 10012",
	"frame": {"x":956,"y":297,"w":239,"h":297},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":239,"h":297},
	"sourceSize": {"w":239,"h":297}
}
,{
	"filename": "Symbol 1 instance 10013",
	"frame": {"x":1195,"y":297,"w":239,"h":297},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":239,"h":297},
	"sourceSize": {"w":239,"h":297}
}
,{
	"filename": "Symbol 1 instance 10014",
	"frame": {"x":1434,"y":297,"w":239,"h":297},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":239,"h":297},
	"sourceSize": {"w":239,"h":297}
}
,{
	"filename": "Symbol 1 instance 10015",
	"frame": {"x":1673,"y":297,"w":239,"h":297},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":239,"h":297},
	"sourceSize": {"w":239,"h":297}
}
,{
	"filename": "Symbol 1 instance 10016",
	"frame": {"x":0,"y":594,"w":239,"h":297},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":239,"h":297},
	"sourceSize": {"w":239,"h":297}
}
,{
	"filename": "Symbol 1 instance 10017",
	"frame": {"x":239,"y":594,"w":239,"h":297},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":239,"h":297},
	"sourceSize": {"w":239,"h":297}
}
,{
	"filename": "Symbol 1 instance 10018",
	"frame": {"x":478,"y":594,"w":239,"h":297},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":239,"h":297},
	"sourceSize": {"w":239,"h":297}
}
,{
	"filename": "Symbol 1 instance 10019",
	"frame": {"x":717,"y":594,"w":239,"h":297},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":239,"h":297},
	"sourceSize": {"w":239,"h":297}
}
,{
	"filename": "Symbol 1 instance 10020",
	"frame": {"x":956,"y":594,"w":239,"h":297},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":239,"h":297},
	"sourceSize": {"w":239,"h":297}
}
,{
	"filename": "Symbol 1 instance 10021",
	"frame": {"x":1195,"y":594,"w":239,"h":297},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":239,"h":297},
	"sourceSize": {"w":239,"h":297}
}
,{
	"filename": "Symbol 1 instance 10022",
	"frame": {"x":1434,"y":594,"w":239,"h":297},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":239,"h":297},
	"sourceSize": {"w":239,"h":297}
}
,{
	"filename": "Symbol 1 instance 10023",
	"frame": {"x":1673,"y":594,"w":239,"h":297},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":239,"h":297},
	"sourceSize": {"w":239,"h":297}
}
,{
	"filename": "Symbol 1 instance 10024",
	"frame": {"x":0,"y":891,"w":239,"h":297},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":239,"h":297},
	"sourceSize": {"w":239,"h":297}
}
,{
	"filename": "Symbol 1 instance 10025",
	"frame": {"x":239,"y":891,"w":239,"h":297},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":239,"h":297},
	"sourceSize": {"w":239,"h":297}
}
,{
	"filename": "Symbol 1 instance 10026",
	"frame": {"x":478,"y":891,"w":239,"h":297},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":239,"h":297},
	"sourceSize": {"w":239,"h":297}
}
,{
	"filename": "Symbol 1 instance 10027",
	"frame": {"x":717,"y":891,"w":239,"h":297},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":239,"h":297},
	"sourceSize": {"w":239,"h":297}
}
,{
	"filename": "Symbol 1 instance 10028",
	"frame": {"x":956,"y":891,"w":239,"h":297},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":239,"h":297},
	"sourceSize": {"w":239,"h":297}
}
,{
	"filename": "Symbol 1 instance 10029",
	"frame": {"x":1195,"y":891,"w":239,"h":297},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":239,"h":297},
	"sourceSize": {"w":239,"h":297}
}
,{
	"filename": "Symbol 1 instance 10030",
	"frame": {"x":1434,"y":891,"w":239,"h":297},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":239,"h":297},
	"sourceSize": {"w":239,"h":297}
}
,{
	"filename": "Symbol 1 instance 10031",
	"frame": {"x":1673,"y":891,"w":239,"h":297},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":239,"h":297},
	"sourceSize": {"w":239,"h":297}
}
,{
	"filename": "Symbol 1 instance 10032",
	"frame": {"x":0,"y":1188,"w":239,"h":297},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":239,"h":297},
	"sourceSize": {"w":239,"h":297}
}
,{
	"filename": "Symbol 1 instance 10033",
	"frame": {"x":239,"y":1188,"w":239,"h":297},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":239,"h":297},
	"sourceSize": {"w":239,"h":297}
}
,{
	"filename": "Symbol 1 instance 10034",
	"frame": {"x":478,"y":1188,"w":239,"h":297},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":239,"h":297},
	"sourceSize": {"w":239,"h":297}
}
,{
	"filename": "Symbol 1 instance 10035",
	"frame": {"x":717,"y":1188,"w":239,"h":297},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":239,"h":297},
	"sourceSize": {"w":239,"h":297}
}
,{
	"filename": "Symbol 1 instance 10036",
	"frame": {"x":956,"y":1188,"w":239,"h":297},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":239,"h":297},
	"sourceSize": {"w":239,"h":297}
}
,{
	"filename": "Symbol 1 instance 10037",
	"frame": {"x":1195,"y":1188,"w":239,"h":297},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":239,"h":297},
	"sourceSize": {"w":239,"h":297}
}],
"meta": {
	"app": "Adobe Animate",
	"version": "18.0.0.107",
	"image": "Caterpillar_Happy.png",
	"format": "RGB8",
	"size": {"w":2048,"h":2048},
	"scale": "1"
}
},

	cater_neutralJson : {"frames": [

{
	"filename": "Symbol 1 instance 10000",
	"frame": {"x":0,"y":0,"w":213,"h":255},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":213,"h":255},
	"sourceSize": {"w":213,"h":255}
}
,{
	"filename": "Symbol 1 instance 10001",
	"frame": {"x":213,"y":0,"w":213,"h":255},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":213,"h":255},
	"sourceSize": {"w":213,"h":255}
}
,{
	"filename": "Symbol 1 instance 10002",
	"frame": {"x":426,"y":0,"w":213,"h":255},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":213,"h":255},
	"sourceSize": {"w":213,"h":255}
}
,{
	"filename": "Symbol 1 instance 10003",
	"frame": {"x":639,"y":0,"w":213,"h":255},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":213,"h":255},
	"sourceSize": {"w":213,"h":255}
}
,{
	"filename": "Symbol 1 instance 10004",
	"frame": {"x":0,"y":255,"w":213,"h":255},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":213,"h":255},
	"sourceSize": {"w":213,"h":255}
}
,{
	"filename": "Symbol 1 instance 10005",
	"frame": {"x":213,"y":255,"w":213,"h":255},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":213,"h":255},
	"sourceSize": {"w":213,"h":255}
}
,{
	"filename": "Symbol 1 instance 10006",
	"frame": {"x":426,"y":255,"w":213,"h":255},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":213,"h":255},
	"sourceSize": {"w":213,"h":255}
}
,{
	"filename": "Symbol 1 instance 10007",
	"frame": {"x":639,"y":255,"w":213,"h":255},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":213,"h":255},
	"sourceSize": {"w":213,"h":255}
}
,{
	"filename": "Symbol 1 instance 10008",
	"frame": {"x":0,"y":510,"w":213,"h":255},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":213,"h":255},
	"sourceSize": {"w":213,"h":255}
}
,{
	"filename": "Symbol 1 instance 10009",
	"frame": {"x":213,"y":510,"w":213,"h":255},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":213,"h":255},
	"sourceSize": {"w":213,"h":255}
}
,{
	"filename": "Symbol 1 instance 10010",
	"frame": {"x":426,"y":510,"w":213,"h":255},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":213,"h":255},
	"sourceSize": {"w":213,"h":255}
}
,{
	"filename": "Symbol 1 instance 10011",
	"frame": {"x":639,"y":510,"w":213,"h":255},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":213,"h":255},
	"sourceSize": {"w":213,"h":255}
}
,{
	"filename": "Symbol 1 instance 10012",
	"frame": {"x":0,"y":765,"w":213,"h":255},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":213,"h":255},
	"sourceSize": {"w":213,"h":255}
}
,{
	"filename": "Symbol 1 instance 10013",
	"frame": {"x":213,"y":765,"w":213,"h":255},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":213,"h":255},
	"sourceSize": {"w":213,"h":255}
}
,{
	"filename": "Symbol 1 instance 10014",
	"frame": {"x":426,"y":765,"w":213,"h":255},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":213,"h":255},
	"sourceSize": {"w":213,"h":255}
}
,{
	"filename": "Symbol 1 instance 10015",
	"frame": {"x":639,"y":765,"w":213,"h":255},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":213,"h":255},
	"sourceSize": {"w":213,"h":255}
}
,{
	"filename": "Symbol 1 instance 10016",
	"frame": {"x":0,"y":1020,"w":213,"h":255},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":213,"h":255},
	"sourceSize": {"w":213,"h":255}
}
,{
	"filename": "Symbol 1 instance 10017",
	"frame": {"x":213,"y":1020,"w":213,"h":255},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":213,"h":255},
	"sourceSize": {"w":213,"h":255}
}
,{
	"filename": "Symbol 1 instance 10018",
	"frame": {"x":426,"y":1020,"w":213,"h":255},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":213,"h":255},
	"sourceSize": {"w":213,"h":255}
}
,{
	"filename": "Symbol 1 instance 10019",
	"frame": {"x":639,"y":1020,"w":213,"h":255},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":213,"h":255},
	"sourceSize": {"w":213,"h":255}
}
,{
	"filename": "Symbol 1 instance 10020",
	"frame": {"x":0,"y":1275,"w":213,"h":255},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":213,"h":255},
	"sourceSize": {"w":213,"h":255}
}
,{
	"filename": "Symbol 1 instance 10021",
	"frame": {"x":213,"y":1275,"w":213,"h":255},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":213,"h":255},
	"sourceSize": {"w":213,"h":255}
}
,{
	"filename": "Symbol 1 instance 10022",
	"frame": {"x":426,"y":1275,"w":213,"h":255},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":213,"h":255},
	"sourceSize": {"w":213,"h":255}
}
,{
	"filename": "Symbol 1 instance 10023",
	"frame": {"x":639,"y":1275,"w":213,"h":255},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":213,"h":255},
	"sourceSize": {"w":213,"h":255}
}
,{
	"filename": "Symbol 1 instance 10024",
	"frame": {"x":0,"y":1530,"w":213,"h":255},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":213,"h":255},
	"sourceSize": {"w":213,"h":255}
}
,{
	"filename": "Symbol 1 instance 10025",
	"frame": {"x":213,"y":1530,"w":213,"h":255},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":213,"h":255},
	"sourceSize": {"w":213,"h":255}
}],
"meta": {
	"app": "Adobe Animate",
	"version": "18.0.0.107",
	"image": "Caterpillar_Neutral.png",
	"format": "RGB8",
	"size": {"w":943,"h":2048},
	"scale": "1"
}
},

    cater_sadJson : {"frames": [

{
	"filename": "Symbol 3 instance 10000",
	"frame": {"x":0,"y":0,"w":228,"h":262},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":228,"h":262},
	"sourceSize": {"w":228,"h":262}
}
,{
	"filename": "Symbol 3 instance 10001",
	"frame": {"x":0,"y":262,"w":228,"h":262},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":228,"h":262},
	"sourceSize": {"w":228,"h":262}
}
,{
	"filename": "Symbol 3 instance 10002",
	"frame": {"x":0,"y":524,"w":228,"h":262},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":228,"h":262},
	"sourceSize": {"w":228,"h":262}
}
,{
	"filename": "Symbol 3 instance 10003",
	"frame": {"x":0,"y":786,"w":228,"h":262},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":228,"h":262},
	"sourceSize": {"w":228,"h":262}
}
,{
	"filename": "Symbol 3 instance 10004",
	"frame": {"x":0,"y":1048,"w":228,"h":262},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":228,"h":262},
	"sourceSize": {"w":228,"h":262}
}
,{
	"filename": "Symbol 3 instance 10005",
	"frame": {"x":228,"y":0,"w":228,"h":262},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":228,"h":262},
	"sourceSize": {"w":228,"h":262}
}
,{
	"filename": "Symbol 3 instance 10006",
	"frame": {"x":228,"y":262,"w":228,"h":262},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":228,"h":262},
	"sourceSize": {"w":228,"h":262}
}
,{
	"filename": "Symbol 3 instance 10007",
	"frame": {"x":228,"y":524,"w":228,"h":262},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":228,"h":262},
	"sourceSize": {"w":228,"h":262}
}
,{
	"filename": "Symbol 3 instance 10008",
	"frame": {"x":228,"y":786,"w":228,"h":262},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":228,"h":262},
	"sourceSize": {"w":228,"h":262}
}
,{
	"filename": "Symbol 3 instance 10009",
	"frame": {"x":228,"y":1048,"w":228,"h":262},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":228,"h":262},
	"sourceSize": {"w":228,"h":262}
}
,{
	"filename": "Symbol 3 instance 10010",
	"frame": {"x":456,"y":0,"w":228,"h":262},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":228,"h":262},
	"sourceSize": {"w":228,"h":262}
}
,{
	"filename": "Symbol 3 instance 10011",
	"frame": {"x":456,"y":262,"w":228,"h":262},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":228,"h":262},
	"sourceSize": {"w":228,"h":262}
}
,{
	"filename": "Symbol 3 instance 10012",
	"frame": {"x":456,"y":524,"w":228,"h":262},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":228,"h":262},
	"sourceSize": {"w":228,"h":262}
}
,{
	"filename": "Symbol 3 instance 10013",
	"frame": {"x":456,"y":786,"w":228,"h":262},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":228,"h":262},
	"sourceSize": {"w":228,"h":262}
}
,{
	"filename": "Symbol 3 instance 10014",
	"frame": {"x":456,"y":1048,"w":228,"h":262},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":228,"h":262},
	"sourceSize": {"w":228,"h":262}
}
,{
	"filename": "Symbol 3 instance 10015",
	"frame": {"x":684,"y":0,"w":228,"h":262},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":228,"h":262},
	"sourceSize": {"w":228,"h":262}
}
,{
	"filename": "Symbol 3 instance 10016",
	"frame": {"x":684,"y":262,"w":228,"h":262},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":228,"h":262},
	"sourceSize": {"w":228,"h":262}
}
,{
	"filename": "Symbol 3 instance 10017",
	"frame": {"x":684,"y":524,"w":228,"h":262},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":228,"h":262},
	"sourceSize": {"w":228,"h":262}
}
,{
	"filename": "Symbol 3 instance 10018",
	"frame": {"x":684,"y":786,"w":228,"h":262},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":228,"h":262},
	"sourceSize": {"w":228,"h":262}
}
,{
	"filename": "Symbol 3 instance 10019",
	"frame": {"x":684,"y":1048,"w":228,"h":262},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":228,"h":262},
	"sourceSize": {"w":228,"h":262}
}
,{
	"filename": "Symbol 3 instance 10020",
	"frame": {"x":912,"y":0,"w":228,"h":262},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":228,"h":262},
	"sourceSize": {"w":228,"h":262}
}
,{
	"filename": "Symbol 3 instance 10021",
	"frame": {"x":1140,"y":0,"w":228,"h":262},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":228,"h":262},
	"sourceSize": {"w":228,"h":262}
}
,{
	"filename": "Symbol 3 instance 10022",
	"frame": {"x":1368,"y":0,"w":228,"h":262},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":228,"h":262},
	"sourceSize": {"w":228,"h":262}
}
,{
	"filename": "Symbol 3 instance 10023",
	"frame": {"x":1596,"y":0,"w":228,"h":262},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":228,"h":262},
	"sourceSize": {"w":228,"h":262}
}
,{
	"filename": "Symbol 3 instance 10024",
	"frame": {"x":912,"y":262,"w":228,"h":262},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":228,"h":262},
	"sourceSize": {"w":228,"h":262}
}
,{
	"filename": "Symbol 3 instance 10025",
	"frame": {"x":912,"y":524,"w":228,"h":262},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":228,"h":262},
	"sourceSize": {"w":228,"h":262}
}
,{
	"filename": "Symbol 3 instance 10026",
	"frame": {"x":912,"y":786,"w":228,"h":262},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":228,"h":262},
	"sourceSize": {"w":228,"h":262}
}
,{
	"filename": "Symbol 3 instance 10027",
	"frame": {"x":912,"y":1048,"w":228,"h":262},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":228,"h":262},
	"sourceSize": {"w":228,"h":262}
}
,{
	"filename": "Symbol 3 instance 10028",
	"frame": {"x":1140,"y":262,"w":228,"h":262},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":228,"h":262},
	"sourceSize": {"w":228,"h":262}
}
,{
	"filename": "Symbol 3 instance 10029",
	"frame": {"x":1368,"y":262,"w":228,"h":262},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":228,"h":262},
	"sourceSize": {"w":228,"h":262}
}
,{
	"filename": "Symbol 3 instance 10030",
	"frame": {"x":1596,"y":262,"w":228,"h":262},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":228,"h":262},
	"sourceSize": {"w":228,"h":262}
}
,{
	"filename": "Symbol 3 instance 10031",
	"frame": {"x":1140,"y":524,"w":228,"h":262},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":228,"h":262},
	"sourceSize": {"w":228,"h":262}
}
,{
	"filename": "Symbol 3 instance 10032",
	"frame": {"x":1140,"y":786,"w":228,"h":262},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":228,"h":262},
	"sourceSize": {"w":228,"h":262}
}
,{
	"filename": "Symbol 3 instance 10033",
	"frame": {"x":1140,"y":1048,"w":228,"h":262},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":228,"h":262},
	"sourceSize": {"w":228,"h":262}
}
,{
	"filename": "Symbol 3 instance 10034",
	"frame": {"x":1368,"y":524,"w":228,"h":262},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":228,"h":262},
	"sourceSize": {"w":228,"h":262}
}
,{
	"filename": "Symbol 3 instance 10035",
	"frame": {"x":1596,"y":524,"w":228,"h":262},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":228,"h":262},
	"sourceSize": {"w":228,"h":262}
}
,{
	"filename": "Symbol 3 instance 10036",
	"frame": {"x":1368,"y":786,"w":228,"h":262},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":228,"h":262},
	"sourceSize": {"w":228,"h":262}
}
,{
	"filename": "Symbol 3 instance 10037",
	"frame": {"x":1368,"y":1048,"w":228,"h":262},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":228,"h":262},
	"sourceSize": {"w":228,"h":262}
}
,{
	"filename": "Symbol 3 instance 10038",
	"frame": {"x":1596,"y":786,"w":228,"h":262},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":228,"h":262},
	"sourceSize": {"w":228,"h":262}
}],
"meta": {
	"app": "Adobe Animate",
	"version": "18.0.0.107",
	"image": "Caterpillar_Sad.png",
	"format": "RGB8",
	"size": {"w":2048,"h":1371},
	"scale": "1"
}
},

    tickJson : {"frames": [

{
	"filename": "Symbol 14 copy instance 10000",
	"frame": {"x":0,"y":0,"w":58,"h":61},
	"rotated": false,
	"trimmed": true,
	"spriteSourceSize": {"x":0,"y":0,"w":64,"h":68},
	"sourceSize": {"w":64,"h":68}
}
,{
	"filename": "Symbol 14 copy instance 10001",
	"frame": {"x":58,"y":0,"w":59,"h":62},
	"rotated": false,
	"trimmed": true,
	"spriteSourceSize": {"x":5,"y":6,"w":64,"h":68},
	"sourceSize": {"w":64,"h":68}
}],
"meta": {
	"app": "Adobe Animate",
	"version": "15.1.0.210",
	"image": "right btn.png",
	"format": "RGB8",
	"size": {"w":121,"h":62},
	"scale": "1"
}
},
    
jumpingWaterJson: {"frames": [
{
	"filename": "Symbol 4 instance 10000",
	"frame": {"x":0,"y":0,"w":65,"h":65},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":65,"h":65},
	"sourceSize": {"w":65,"h":65}
}
,{
	"filename": "Symbol 4 instance 10001",
	"frame": {"x":65,"y":0,"w":65,"h":65},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":65,"h":65},
	"sourceSize": {"w":65,"h":65}
}
,{
	"filename": "Symbol 4 instance 10002",
	"frame": {"x":130,"y":0,"w":65,"h":65},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":65,"h":65},
	"sourceSize": {"w":65,"h":65}
}
,{
	"filename": "Symbol 4 instance 10003",
	"frame": {"x":195,"y":0,"w":65,"h":65},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":65,"h":65},
	"sourceSize": {"w":65,"h":65}
}
,{
	"filename": "Symbol 4 instance 10004",
	"frame": {"x":260,"y":0,"w":65,"h":65},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":65,"h":65},
	"sourceSize": {"w":65,"h":65}
}
,{
	"filename": "Symbol 4 instance 10005",
	"frame": {"x":325,"y":0,"w":65,"h":65},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":65,"h":65},
	"sourceSize": {"w":65,"h":65}
}
,{
	"filename": "Symbol 4 instance 10006",
	"frame": {"x":390,"y":0,"w":65,"h":65},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":65,"h":65},
	"sourceSize": {"w":65,"h":65}
}
,{
	"filename": "Symbol 4 instance 10007",
	"frame": {"x":455,"y":0,"w":65,"h":65},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":65,"h":65},
	"sourceSize": {"w":65,"h":65}
}
,{
	"filename": "Symbol 4 instance 10008",
	"frame": {"x":520,"y":0,"w":65,"h":65},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":65,"h":65},
	"sourceSize": {"w":65,"h":65}
}
,{
	"filename": "Symbol 4 instance 10009",
	"frame": {"x":585,"y":0,"w":65,"h":65},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":65,"h":65},
	"sourceSize": {"w":65,"h":65}
}
,{
	"filename": "Symbol 4 instance 10010",
	"frame": {"x":650,"y":0,"w":65,"h":65},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":65,"h":65},
	"sourceSize": {"w":65,"h":65}
}
,{
	"filename": "Symbol 4 instance 10011",
	"frame": {"x":715,"y":0,"w":65,"h":65},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":65,"h":65},
	"sourceSize": {"w":65,"h":65}
}
,{
	"filename": "Symbol 4 instance 10012",
	"frame": {"x":780,"y":0,"w":65,"h":65},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":65,"h":65},
	"sourceSize": {"w":65,"h":65}
}],
"meta": {
	"app": "Adobe Animate",
	"version": "20.0.1.19255",
	"image": "Kingfisher jumping water.png",
	"format": "RGBA8888",
	"size": {"w":849,"h":72},
	"scale": "1"
}
},  
    
numberpadJson: {"frames": [

{
	"filename": "Symbol 3 instance 10000",
	"frame": {"x":0,"y":0,"w":68,"h":68},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":68,"h":68},
	"sourceSize": {"w":68,"h":68}
}
,{
	"filename": "Symbol 3 instance 10001",
	"frame": {"x":68,"y":0,"w":68,"h":68},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":68,"h":68},
	"sourceSize": {"w":68,"h":68}
}
,{
	"filename": "Symbol 3 instance 10002",
	"frame": {"x":136,"y":0,"w":68,"h":68},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":68,"h":68},
	"sourceSize": {"w":68,"h":68}
}
,{
	"filename": "Symbol 3 instance 10003",
	"frame": {"x":204,"y":0,"w":68,"h":68},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":68,"h":68},
	"sourceSize": {"w":68,"h":68}
}
,{
	"filename": "Symbol 3 instance 10004",
	"frame": {"x":272,"y":0,"w":68,"h":68},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":68,"h":68},
	"sourceSize": {"w":68,"h":68}
}
,{
	"filename": "Symbol 3 instance 10005",
	"frame": {"x":340,"y":0,"w":68,"h":68},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":68,"h":68},
	"sourceSize": {"w":68,"h":68}
}
,{
	"filename": "Symbol 3 instance 10006",
	"frame": {"x":408,"y":0,"w":68,"h":68},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":68,"h":68},
	"sourceSize": {"w":68,"h":68}
}
,{
	"filename": "Symbol 3 instance 10007",
	"frame": {"x":476,"y":0,"w":68,"h":68},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":68,"h":68},
	"sourceSize": {"w":68,"h":68}
}
,{
	"filename": "Symbol 3 instance 10008",
	"frame": {"x":544,"y":0,"w":68,"h":68},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":68,"h":68},
	"sourceSize": {"w":68,"h":68}
}
,{
	"filename": "Symbol 3 instance 10009",
	"frame": {"x":612,"y":0,"w":68,"h":68},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":68,"h":68},
	"sourceSize": {"w":68,"h":68}
}
,{
	"filename": "Symbol 3 instance 10010",
	"frame": {"x":680,"y":0,"w":68,"h":68},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":68,"h":68},
	"sourceSize": {"w":68,"h":68}
}
,{
	"filename": "Symbol 3 instance 10011",
	"frame": {"x":748,"y":0,"w":68,"h":68},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":68,"h":68},
	"sourceSize": {"w":68,"h":68}
}
,{
	"filename": "Symbol 3 instance 10012",
	"frame": {"x":816,"y":0,"w":68,"h":68},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":68,"h":68},
	"sourceSize": {"w":68,"h":68}
}
,{
	"filename": "Symbol 3 instance 10013",
	"frame": {"x":884,"y":0,"w":68,"h":68},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":68,"h":68},
	"sourceSize": {"w":68,"h":68}
}],
"meta": {
	"app": "Adobe Animate",
	"version": "20.0.1.19255",
	"image": "number 0 to 9.png",
	"format": "RGBA8888",
	"size": {"w":952,"h":68},
	"scale": "1"
}
},

ScreenTextBox: {"frames": [

{
	"filename": "Symbol 14 instance 10000",
	"frame": {"x":0,"y":0,"w":159,"h":87},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":159,"h":87},
	"sourceSize": {"w":159,"h":87}
}
,{
	"filename": "Symbol 14 instance 10001",
	"frame": {"x":159,"y":0,"w":159,"h":87},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":159,"h":87},
	"sourceSize": {"w":159,"h":87}
}],
"meta": {
	"app": "Adobe Animate",
	"version": "19.2.1.408",
	"image": "Box2.png.png",
	"format": "RGBA8888",
	"size": {"w":319,"h":87},
	"scale": "1"
}
},

comingUpJson: {"frames": [
{
	"filename": "Symbol 4 copy instance 10000",
	"frame": {"x":0,"y":0,"w":68,"h":65},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":68,"h":65},
	"sourceSize": {"w":68,"h":65}
}
,{
	"filename": "Symbol 4 copy instance 10001",
	"frame": {"x":68,"y":0,"w":68,"h":65},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":68,"h":65},
	"sourceSize": {"w":68,"h":65}
}
,{
	"filename": "Symbol 4 copy instance 10002",
	"frame": {"x":136,"y":0,"w":68,"h":65},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":68,"h":65},
	"sourceSize": {"w":68,"h":65}
}
,{
	"filename": "Symbol 4 copy instance 10003",
	"frame": {"x":204,"y":0,"w":68,"h":65},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":68,"h":65},
	"sourceSize": {"w":68,"h":65}
}
,{
	"filename": "Symbol 4 copy instance 10004",
	"frame": {"x":272,"y":0,"w":68,"h":65},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":68,"h":65},
	"sourceSize": {"w":68,"h":65}
}
,{
	"filename": "Symbol 4 copy instance 10005",
	"frame": {"x":340,"y":0,"w":68,"h":65},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":68,"h":65},
	"sourceSize": {"w":68,"h":65}
}
,{
	"filename": "Symbol 4 copy instance 10006",
	"frame": {"x":408,"y":0,"w":68,"h":65},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":68,"h":65},
	"sourceSize": {"w":68,"h":65}
}
,{
	"filename": "Symbol 4 copy instance 10007",
	"frame": {"x":476,"y":0,"w":68,"h":65},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":68,"h":65},
	"sourceSize": {"w":68,"h":65}
}
,{
	"filename": "Symbol 4 copy instance 10008",
	"frame": {"x":544,"y":0,"w":68,"h":65},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":68,"h":65},
	"sourceSize": {"w":68,"h":65}
}
,{
	"filename": "Symbol 4 copy instance 10009",
	"frame": {"x":612,"y":0,"w":68,"h":65},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":68,"h":65},
	"sourceSize": {"w":68,"h":65}
}
,{
	"filename": "Symbol 4 copy instance 10010",
	"frame": {"x":680,"y":0,"w":68,"h":65},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":68,"h":65},
	"sourceSize": {"w":68,"h":65}
}
,{
	"filename": "Symbol 4 copy instance 10011",
	"frame": {"x":748,"y":0,"w":68,"h":65},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":68,"h":65},
	"sourceSize": {"w":68,"h":65}
}
,{
	"filename": "Symbol 4 copy instance 10012",
	"frame": {"x":816,"y":0,"w":68,"h":65},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":68,"h":65},
	"sourceSize": {"w":68,"h":65}
}],
"meta": {
	"app": "Adobe Animate",
	"version": "20.0.1.19255",
	"image": "holding a fish coming back from water,.png",
	"format": "RGBA8888",
	"size": {"w":918,"h":72},
	"scale": "1"
}    
    
},
    
kingfisherhoveringJson: {"frames": [

{
	"filename": "Symbol 5 instance 10000",
	"frame": {"x":0,"y":0,"w":96,"h":122},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":96,"h":122},
	"sourceSize": {"w":96,"h":122}
}
,{
	"filename": "Symbol 5 instance 10001",
	"frame": {"x":96,"y":0,"w":96,"h":122},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":96,"h":122},
	"sourceSize": {"w":96,"h":122}
}
,{
	"filename": "Symbol 5 instance 10002",
	"frame": {"x":192,"y":0,"w":96,"h":122},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":96,"h":122},
	"sourceSize": {"w":96,"h":122}
}
,{
	"filename": "Symbol 5 instance 10003",
	"frame": {"x":288,"y":0,"w":96,"h":122},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":96,"h":122},
	"sourceSize": {"w":96,"h":122}
}
,{
	"filename": "Symbol 5 instance 10004",
	"frame": {"x":384,"y":0,"w":96,"h":122},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":96,"h":122},
	"sourceSize": {"w":96,"h":122}
}
,{
	"filename": "Symbol 5 instance 10005",
	"frame": {"x":480,"y":0,"w":96,"h":122},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":96,"h":122},
	"sourceSize": {"w":96,"h":122}
}
,{
	"filename": "Symbol 5 instance 10006",
	"frame": {"x":576,"y":0,"w":96,"h":122},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":96,"h":122},
	"sourceSize": {"w":96,"h":122}
}],
"meta": {
	"app": "Adobe Animate",
	"version": "20.0.1.19255",
	"image": "Kingfisher hovering.png",
	"format": "RGBA8888",
	"size": {"w":674,"h":138},
	"scale": "1"
}
},
    
eatingfishJson:{"frames": [

{
	"filename": "Symbol 1 copy 3 instance 10000",
	"frame": {"x":0,"y":0,"w":40,"h":35},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":40,"h":35},
	"sourceSize": {"w":40,"h":35}
}
,{
	"filename": "Symbol 1 copy 3 instance 10001",
	"frame": {"x":40,"y":0,"w":40,"h":35},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":40,"h":35},
	"sourceSize": {"w":40,"h":35}
}
,{
	"filename": "Symbol 1 copy 3 instance 10002",
	"frame": {"x":80,"y":0,"w":40,"h":35},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":40,"h":35},
	"sourceSize": {"w":40,"h":35}
}
,{
	"filename": "Symbol 1 copy 3 instance 10003",
	"frame": {"x":120,"y":0,"w":40,"h":35},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":40,"h":35},
	"sourceSize": {"w":40,"h":35}
}
,{
	"filename": "Symbol 1 copy 3 instance 10004",
	"frame": {"x":160,"y":0,"w":40,"h":35},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":40,"h":35},
	"sourceSize": {"w":40,"h":35}
}
,{
	"filename": "Symbol 1 copy 3 instance 10005",
	"frame": {"x":200,"y":0,"w":40,"h":35},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":40,"h":35},
	"sourceSize": {"w":40,"h":35}
}
,{
	"filename": "Symbol 1 copy 3 instance 10006",
	"frame": {"x":240,"y":0,"w":40,"h":35},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":40,"h":35},
	"sourceSize": {"w":40,"h":35}
}
,{
	"filename": "Symbol 1 copy 3 instance 10007",
	"frame": {"x":280,"y":0,"w":40,"h":35},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":40,"h":35},
	"sourceSize": {"w":40,"h":35}
}
,{
	"filename": "Symbol 1 copy 3 instance 10008",
	"frame": {"x":320,"y":0,"w":40,"h":35},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":40,"h":35},
	"sourceSize": {"w":40,"h":35}
}],
"meta": {
	"app": "Adobe Animate",
	"version": "20.0.1.19255",
	"image": "Kingfisher Eating Fish.png",
	"format": "RGBA8888",
	"size": {"w":366,"h":35},
	"scale": "1"
}
},
bubbleAnimJSon: {"frames": [

{
	"filename": "Symbol 12 instance 10000",
	"frame": {"x":0,"y":0,"w":60,"h":135},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":60,"h":135},
	"sourceSize": {"w":60,"h":135}
}
,{
	"filename": "Symbol 12 instance 10001",
	"frame": {"x":60,"y":0,"w":60,"h":135},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":60,"h":135},
	"sourceSize": {"w":60,"h":135}
}
,{
	"filename": "Symbol 12 instance 10002",
	"frame": {"x":120,"y":0,"w":60,"h":135},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":60,"h":135},
	"sourceSize": {"w":60,"h":135}
}
,{
	"filename": "Symbol 12 instance 10003",
	"frame": {"x":180,"y":0,"w":60,"h":135},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":60,"h":135},
	"sourceSize": {"w":60,"h":135}
}
,{
	"filename": "Symbol 12 instance 10004",
	"frame": {"x":240,"y":0,"w":60,"h":135},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":60,"h":135},
	"sourceSize": {"w":60,"h":135}
}
,{
	"filename": "Symbol 12 instance 10005",
	"frame": {"x":300,"y":0,"w":60,"h":135},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":60,"h":135},
	"sourceSize": {"w":60,"h":135}
}
,{
	"filename": "Symbol 12 instance 10006",
	"frame": {"x":360,"y":0,"w":60,"h":135},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":60,"h":135},
	"sourceSize": {"w":60,"h":135}
}
,{
	"filename": "Symbol 12 instance 10007",
	"frame": {"x":420,"y":0,"w":60,"h":135},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":60,"h":135},
	"sourceSize": {"w":60,"h":135}
}
,{
	"filename": "Symbol 12 instance 10008",
	"frame": {"x":480,"y":0,"w":60,"h":135},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":60,"h":135},
	"sourceSize": {"w":60,"h":135}
}
,{
	"filename": "Symbol 12 instance 10009",
	"frame": {"x":540,"y":0,"w":60,"h":135},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":60,"h":135},
	"sourceSize": {"w":60,"h":135}
}
,{
	"filename": "Symbol 12 instance 10010",
	"frame": {"x":600,"y":0,"w":60,"h":135},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":60,"h":135},
	"sourceSize": {"w":60,"h":135}
}
,{
	"filename": "Symbol 12 instance 10011",
	"frame": {"x":660,"y":0,"w":60,"h":135},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":60,"h":135},
	"sourceSize": {"w":60,"h":135}
}
,{
	"filename": "Symbol 12 instance 10012",
	"frame": {"x":720,"y":0,"w":60,"h":135},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":60,"h":135},
	"sourceSize": {"w":60,"h":135}
}
,{
	"filename": "Symbol 12 instance 10013",
	"frame": {"x":780,"y":0,"w":60,"h":135},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":60,"h":135},
	"sourceSize": {"w":60,"h":135}
}
,{
	"filename": "Symbol 12 instance 10014",
	"frame": {"x":840,"y":0,"w":60,"h":135},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":60,"h":135},
	"sourceSize": {"w":60,"h":135}
}
,{
	"filename": "Symbol 12 instance 10015",
	"frame": {"x":900,"y":0,"w":60,"h":135},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":60,"h":135},
	"sourceSize": {"w":60,"h":135}
}
,{
	"filename": "Symbol 12 instance 10016",
	"frame": {"x":960,"y":0,"w":60,"h":135},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":60,"h":135},
	"sourceSize": {"w":60,"h":135}
}
,{
	"filename": "Symbol 12 instance 10017",
	"frame": {"x":1020,"y":0,"w":60,"h":135},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":60,"h":135},
	"sourceSize": {"w":60,"h":135}
}
,{
	"filename": "Symbol 12 instance 10018",
	"frame": {"x":1080,"y":0,"w":60,"h":135},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":60,"h":135},
	"sourceSize": {"w":60,"h":135}
}
,{
	"filename": "Symbol 12 instance 10019",
	"frame": {"x":1140,"y":0,"w":60,"h":135},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":60,"h":135},
	"sourceSize": {"w":60,"h":135}
}
,{
	"filename": "Symbol 12 instance 10020",
	"frame": {"x":1200,"y":0,"w":60,"h":135},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":60,"h":135},
	"sourceSize": {"w":60,"h":135}
}
,{
	"filename": "Symbol 12 instance 10021",
	"frame": {"x":1260,"y":0,"w":60,"h":135},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":60,"h":135},
	"sourceSize": {"w":60,"h":135}
}
,{
	"filename": "Symbol 12 instance 10022",
	"frame": {"x":1320,"y":0,"w":60,"h":135},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":60,"h":135},
	"sourceSize": {"w":60,"h":135}
}
,{
	"filename": "Symbol 12 instance 10023",
	"frame": {"x":1380,"y":0,"w":60,"h":135},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":60,"h":135},
	"sourceSize": {"w":60,"h":135}
}
,{
	"filename": "Symbol 12 instance 10024",
	"frame": {"x":0,"y":135,"w":60,"h":135},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":60,"h":135},
	"sourceSize": {"w":60,"h":135}
}
,{
	"filename": "Symbol 12 instance 10025",
	"frame": {"x":60,"y":135,"w":60,"h":135},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":60,"h":135},
	"sourceSize": {"w":60,"h":135}
}
,{
	"filename": "Symbol 12 instance 10026",
	"frame": {"x":120,"y":135,"w":60,"h":135},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":60,"h":135},
	"sourceSize": {"w":60,"h":135}
}
,{
	"filename": "Symbol 12 instance 10027",
	"frame": {"x":180,"y":135,"w":60,"h":135},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":60,"h":135},
	"sourceSize": {"w":60,"h":135}
}
,{
	"filename": "Symbol 12 instance 10028",
	"frame": {"x":240,"y":135,"w":60,"h":135},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":60,"h":135},
	"sourceSize": {"w":60,"h":135}
}
,{
	"filename": "Symbol 12 instance 10029",
	"frame": {"x":300,"y":135,"w":60,"h":135},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":60,"h":135},
	"sourceSize": {"w":60,"h":135}
}
,{
	"filename": "Symbol 12 instance 10030",
	"frame": {"x":360,"y":135,"w":60,"h":135},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":60,"h":135},
	"sourceSize": {"w":60,"h":135}
}
,{
	"filename": "Symbol 12 instance 10031",
	"frame": {"x":420,"y":135,"w":60,"h":135},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":60,"h":135},
	"sourceSize": {"w":60,"h":135}
}
,{
	"filename": "Symbol 12 instance 10032",
	"frame": {"x":480,"y":135,"w":60,"h":135},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":60,"h":135},
	"sourceSize": {"w":60,"h":135}
}
,{
	"filename": "Symbol 12 instance 10033",
	"frame": {"x":540,"y":135,"w":60,"h":135},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":60,"h":135},
	"sourceSize": {"w":60,"h":135}
}
,{
	"filename": "Symbol 12 instance 10034",
	"frame": {"x":600,"y":135,"w":60,"h":135},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":60,"h":135},
	"sourceSize": {"w":60,"h":135}
}
,{
	"filename": "Symbol 12 instance 10035",
	"frame": {"x":660,"y":135,"w":60,"h":135},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":60,"h":135},
	"sourceSize": {"w":60,"h":135}
}
,{
	"filename": "Symbol 12 instance 10036",
	"frame": {"x":720,"y":135,"w":60,"h":135},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":60,"h":135},
	"sourceSize": {"w":60,"h":135}
}
,{
	"filename": "Symbol 12 instance 10037",
	"frame": {"x":780,"y":135,"w":60,"h":135},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":60,"h":135},
	"sourceSize": {"w":60,"h":135}
}
,{
	"filename": "Symbol 12 instance 10038",
	"frame": {"x":840,"y":135,"w":60,"h":135},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":60,"h":135},
	"sourceSize": {"w":60,"h":135}
}
,{
	"filename": "Symbol 12 instance 10039",
	"frame": {"x":900,"y":135,"w":60,"h":135},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":60,"h":135},
	"sourceSize": {"w":60,"h":135}
}],
"meta": {
	"app": "Adobe Animate",
	"version": "20.0.1.19255",
	"image": "Bubble anim.png",
	"format": "RGBA8888",
	"size": {"w":1458,"h":275},
	"scale": "1"
}
},    

comingupWaterJson: {"frames": [

{
	"filename": "Symbol 4 copy instance 10000",
	"frame": {"x":0,"y":0,"w":68,"h":64},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":68,"h":64},
	"sourceSize": {"w":68,"h":64}
}
,{
	"filename": "Symbol 4 copy instance 10001",
	"frame": {"x":68,"y":0,"w":68,"h":64},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":68,"h":64},
	"sourceSize": {"w":68,"h":64}
}
,{
	"filename": "Symbol 4 copy instance 10002",
	"frame": {"x":136,"y":0,"w":68,"h":64},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":68,"h":64},
	"sourceSize": {"w":68,"h":64}
}
,{
	"filename": "Symbol 4 copy instance 10003",
	"frame": {"x":204,"y":0,"w":68,"h":64},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":68,"h":64},
	"sourceSize": {"w":68,"h":64}
}
,{
	"filename": "Symbol 4 copy instance 10004",
	"frame": {"x":272,"y":0,"w":68,"h":64},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":68,"h":64},
	"sourceSize": {"w":68,"h":64}
}
,{
	"filename": "Symbol 4 copy instance 10005",
	"frame": {"x":340,"y":0,"w":68,"h":64},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":68,"h":64},
	"sourceSize": {"w":68,"h":64}
}
,{
	"filename": "Symbol 4 copy instance 10006",
	"frame": {"x":408,"y":0,"w":68,"h":64},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":68,"h":64},
	"sourceSize": {"w":68,"h":64}
}
,{
	"filename": "Symbol 4 copy instance 10007",
	"frame": {"x":476,"y":0,"w":68,"h":64},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":68,"h":64},
	"sourceSize": {"w":68,"h":64}
}
,{
	"filename": "Symbol 4 copy instance 10008",
	"frame": {"x":544,"y":0,"w":68,"h":64},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":68,"h":64},
	"sourceSize": {"w":68,"h":64}
}
,{
	"filename": "Symbol 4 copy instance 10009",
	"frame": {"x":612,"y":0,"w":68,"h":64},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":68,"h":64},
	"sourceSize": {"w":68,"h":64}
}
,{
	"filename": "Symbol 4 copy instance 10010",
	"frame": {"x":680,"y":0,"w":68,"h":64},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":68,"h":64},
	"sourceSize": {"w":68,"h":64}
}
,{
	"filename": "Symbol 4 copy instance 10011",
	"frame": {"x":748,"y":0,"w":68,"h":64},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":68,"h":64},
	"sourceSize": {"w":68,"h":64}
}
,{
	"filename": "Symbol 4 copy instance 10012",
	"frame": {"x":816,"y":0,"w":68,"h":64},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":68,"h":64},
	"sourceSize": {"w":68,"h":64}
}],
"meta": {
	"app": "Adobe Animate",
	"version": "20.0.1.19255",
	"image": "Kingfisher Return to under Water.png",
	"format": "RGBA8888",
	"size": {"w":886,"h":68},
	"scale": "1"
}
},

SplashWater: {"frames": [

{
	"filename": "Symbol 1 copy 4 instance 10000",
	"frame": {"x":0,"y":0,"w":320,"h":56},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":320,"h":56},
	"sourceSize": {"w":320,"h":56}
}
,{
	"filename": "Symbol 1 copy 4 instance 10001",
	"frame": {"x":320,"y":0,"w":320,"h":56},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":320,"h":56},
	"sourceSize": {"w":320,"h":56}
}
,{
	"filename": "Symbol 1 copy 4 instance 10002",
	"frame": {"x":640,"y":0,"w":320,"h":56},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":320,"h":56},
	"sourceSize": {"w":320,"h":56}
}
,{
	"filename": "Symbol 1 copy 4 instance 10003",
	"frame": {"x":960,"y":0,"w":320,"h":56},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":320,"h":56},
	"sourceSize": {"w":320,"h":56}
}
,{
	"filename": "Symbol 1 copy 4 instance 10004",
	"frame": {"x":1280,"y":0,"w":320,"h":56},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":320,"h":56},
	"sourceSize": {"w":320,"h":56}
}
,{
	"filename": "Symbol 1 copy 4 instance 10005",
	"frame": {"x":1600,"y":0,"w":320,"h":56},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":320,"h":56},
	"sourceSize": {"w":320,"h":56}
}
,{
	"filename": "Symbol 1 copy 4 instance 10006",
	"frame": {"x":1920,"y":0,"w":320,"h":56},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":320,"h":56},
	"sourceSize": {"w":320,"h":56}
}
,{
	"filename": "Symbol 1 copy 4 instance 10007",
	"frame": {"x":2240,"y":0,"w":320,"h":56},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":320,"h":56},
	"sourceSize": {"w":320,"h":56}
}
,{
	"filename": "Symbol 1 copy 4 instance 10008",
	"frame": {"x":2560,"y":0,"w":320,"h":56},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":320,"h":56},
	"sourceSize": {"w":320,"h":56}
}
,{
	"filename": "Symbol 1 copy 4 instance 10009",
	"frame": {"x":2880,"y":0,"w":320,"h":56},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":320,"h":56},
	"sourceSize": {"w":320,"h":56}
}
,{
	"filename": "Symbol 1 copy 4 instance 10010",
	"frame": {"x":3200,"y":0,"w":320,"h":56},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":320,"h":56},
	"sourceSize": {"w":320,"h":56}
}
,{
	"filename": "Symbol 1 copy 4 instance 10011",
	"frame": {"x":3520,"y":0,"w":320,"h":56},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":320,"h":56},
	"sourceSize": {"w":320,"h":56}
}
,{
	"filename": "Symbol 1 copy 4 instance 10012",
	"frame": {"x":3840,"y":0,"w":320,"h":56},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":320,"h":56},
	"sourceSize": {"w":320,"h":56}
}
,{
	"filename": "Symbol 1 copy 4 instance 10013",
	"frame": {"x":4160,"y":0,"w":320,"h":56},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":320,"h":56},
	"sourceSize": {"w":320,"h":56}
}],
"meta": {
	"app": "Adobe Animate",
	"version": "20.0.1.19255",
	"image": "Water splash anim.png",
	"format": "RGBA8888",
	"size": {"w":4500,"h":167},
	"scale": "1"
}
},

homebtnJson: {"frames": [

{
	"filename": "Symbol 4 instance 10000",
	"frame": {"x":0,"y":0,"w":60,"h":60},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":60,"h":60},
	"sourceSize": {"w":60,"h":60}
}
,{
	"filename": "Symbol 4 instance 10001",
	"frame": {"x":0,"y":60,"w":60,"h":60},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":60,"h":60},
	"sourceSize": {"w":60,"h":60}
}],
"meta": {
	"app": "Adobe Animate",
	"version": "18.0.1.115",
	"image": "H.png",
	"format": "RGB8",
	"size": {"w":64,"h":128},
	"scale": "1"
}
},
    
nextbtnJson: {"frames": [

{
	"filename": "Symbol 6 instance 10000",
	"frame": {"x":0,"y":0,"w":59,"h":60},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":59,"h":60},
	"sourceSize": {"w":59,"h":60}
}
,{
	"filename": "Symbol 6 instance 10001",
	"frame": {"x":0,"y":60,"w":59,"h":60},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":59,"h":60},
	"sourceSize": {"w":59,"h":60}
}],
"meta": {
	"app": "Adobe Animate",
	"version": "18.0.1.115",
	"image": "N.png",
	"format": "RGB8",
	"size": {"w":64,"h":128},
	"scale": "1"
}
},

fishbowlJson: {"frames": [

{
	"filename": "Symbol 20 instance 10000",
	"frame": {"x":0,"y":0,"w":90,"h":82},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":90,"h":82},
	"sourceSize": {"w":90,"h":82}
}
,{
	"filename": "Symbol 20 instance 10001",
	"frame": {"x":90,"y":0,"w":90,"h":82},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":90,"h":82},
	"sourceSize": {"w":90,"h":82}
}
,{
	"filename": "Symbol 20 instance 10002",
	"frame": {"x":180,"y":0,"w":90,"h":82},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":90,"h":82},
	"sourceSize": {"w":90,"h":82}
}
,{
	"filename": "Symbol 20 instance 10003",
	"frame": {"x":270,"y":0,"w":90,"h":82},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":90,"h":82},
	"sourceSize": {"w":90,"h":82}
}
,{
	"filename": "Symbol 20 instance 10004",
	"frame": {"x":360,"y":0,"w":90,"h":82},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":90,"h":82},
	"sourceSize": {"w":90,"h":82}
}
,{
	"filename": "Symbol 20 instance 10005",
	"frame": {"x":450,"y":0,"w":90,"h":82},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":90,"h":82},
	"sourceSize": {"w":90,"h":82}
}
,{
	"filename": "Symbol 20 instance 10006",
	"frame": {"x":540,"y":0,"w":90,"h":82},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":90,"h":82},
	"sourceSize": {"w":90,"h":82}
}
,{
	"filename": "Symbol 20 instance 10007",
	"frame": {"x":630,"y":0,"w":90,"h":82},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":90,"h":82},
	"sourceSize": {"w":90,"h":82}
}
,{
	"filename": "Symbol 20 instance 10008",
	"frame": {"x":720,"y":0,"w":90,"h":82},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":90,"h":82},
	"sourceSize": {"w":90,"h":82}
}
,{
	"filename": "Symbol 20 instance 10009",
	"frame": {"x":810,"y":0,"w":90,"h":82},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":90,"h":82},
	"sourceSize": {"w":90,"h":82}
}
,{
	"filename": "Symbol 20 instance 10010",
	"frame": {"x":900,"y":0,"w":90,"h":82},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":90,"h":82},
	"sourceSize": {"w":90,"h":82}
}
,{
	"filename": "Symbol 20 instance 10011",
	"frame": {"x":990,"y":0,"w":90,"h":82},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":90,"h":82},
	"sourceSize": {"w":90,"h":82}
}
,{
	"filename": "Symbol 20 instance 10012",
	"frame": {"x":1080,"y":0,"w":90,"h":82},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":90,"h":82},
	"sourceSize": {"w":90,"h":82}
}
,{
	"filename": "Symbol 20 instance 10013",
	"frame": {"x":1170,"y":0,"w":90,"h":82},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":90,"h":82},
	"sourceSize": {"w":90,"h":82}
}
,{
	"filename": "Symbol 20 instance 10014",
	"frame": {"x":1260,"y":0,"w":90,"h":82},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":90,"h":82},
	"sourceSize": {"w":90,"h":82}
}
,{
	"filename": "Symbol 20 instance 10015",
	"frame": {"x":1350,"y":0,"w":90,"h":82},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":90,"h":82},
	"sourceSize": {"w":90,"h":82}
}
,{
	"filename": "Symbol 20 instance 10016",
	"frame": {"x":1440,"y":0,"w":90,"h":82},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":90,"h":82},
	"sourceSize": {"w":90,"h":82}
}
,{
	"filename": "Symbol 20 instance 10017",
	"frame": {"x":1530,"y":0,"w":90,"h":82},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":90,"h":82},
	"sourceSize": {"w":90,"h":82}
}
,{
	"filename": "Symbol 20 instance 10018",
	"frame": {"x":1620,"y":0,"w":90,"h":82},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":90,"h":82},
	"sourceSize": {"w":90,"h":82}
}
,{
	"filename": "Symbol 20 instance 10019",
	"frame": {"x":1710,"y":0,"w":90,"h":82},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":90,"h":82},
	"sourceSize": {"w":90,"h":82}
}
,{
	"filename": "Symbol 20 instance 10020",
	"frame": {"x":1800,"y":0,"w":90,"h":82},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":90,"h":82},
	"sourceSize": {"w":90,"h":82}
}
,{
	"filename": "Symbol 20 instance 10021",
	"frame": {"x":1890,"y":0,"w":90,"h":82},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":90,"h":82},
	"sourceSize": {"w":90,"h":82}
}
,{
	"filename": "Symbol 20 instance 10022",
	"frame": {"x":1980,"y":0,"w":90,"h":82},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":90,"h":82},
	"sourceSize": {"w":90,"h":82}
}
,{
	"filename": "Symbol 20 instance 10023",
	"frame": {"x":2070,"y":0,"w":90,"h":82},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":90,"h":82},
	"sourceSize": {"w":90,"h":82}
}
,{
	"filename": "Symbol 20 instance 10024",
	"frame": {"x":2160,"y":0,"w":90,"h":82},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":90,"h":82},
	"sourceSize": {"w":90,"h":82}
}
,{
	"filename": "Symbol 20 instance 10025",
	"frame": {"x":2250,"y":0,"w":90,"h":82},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":90,"h":82},
	"sourceSize": {"w":90,"h":82}
}
,{
	"filename": "Symbol 20 instance 10026",
	"frame": {"x":2340,"y":0,"w":90,"h":82},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":90,"h":82},
	"sourceSize": {"w":90,"h":82}
}
,{
	"filename": "Symbol 20 instance 10027",
	"frame": {"x":2430,"y":0,"w":90,"h":82},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":90,"h":82},
	"sourceSize": {"w":90,"h":82}
}
,{
	"filename": "Symbol 20 instance 10028",
	"frame": {"x":2520,"y":0,"w":90,"h":82},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":90,"h":82},
	"sourceSize": {"w":90,"h":82}
}
,{
	"filename": "Symbol 20 instance 10029",
	"frame": {"x":2610,"y":0,"w":90,"h":82},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":90,"h":82},
	"sourceSize": {"w":90,"h":82}
}
,{
	"filename": "Symbol 20 instance 10030",
	"frame": {"x":2700,"y":0,"w":90,"h":82},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":90,"h":82},
	"sourceSize": {"w":90,"h":82}
}
,{
	"filename": "Symbol 20 instance 10031",
	"frame": {"x":2790,"y":0,"w":90,"h":82},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":90,"h":82},
	"sourceSize": {"w":90,"h":82}
}
,{
	"filename": "Symbol 20 instance 10032",
	"frame": {"x":2880,"y":0,"w":90,"h":82},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":90,"h":82},
	"sourceSize": {"w":90,"h":82}
}
,{
	"filename": "Symbol 20 instance 10033",
	"frame": {"x":2970,"y":0,"w":90,"h":82},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":90,"h":82},
	"sourceSize": {"w":90,"h":82}
}
,{
	"filename": "Symbol 20 instance 10034",
	"frame": {"x":3060,"y":0,"w":90,"h":82},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":90,"h":82},
	"sourceSize": {"w":90,"h":82}
}
,{
	"filename": "Symbol 20 instance 10035",
	"frame": {"x":3150,"y":0,"w":90,"h":82},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":90,"h":82},
	"sourceSize": {"w":90,"h":82}
}
,{
	"filename": "Symbol 20 instance 10036",
	"frame": {"x":3240,"y":0,"w":90,"h":82},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":90,"h":82},
	"sourceSize": {"w":90,"h":82}
}
,{
	"filename": "Symbol 20 instance 10037",
	"frame": {"x":3330,"y":0,"w":90,"h":82},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":90,"h":82},
	"sourceSize": {"w":90,"h":82}
}
,{
	"filename": "Symbol 20 instance 10038",
	"frame": {"x":3420,"y":0,"w":90,"h":82},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":90,"h":82},
	"sourceSize": {"w":90,"h":82}
}
,{
	"filename": "Symbol 20 instance 10039",
	"frame": {"x":3510,"y":0,"w":90,"h":82},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":90,"h":82},
	"sourceSize": {"w":90,"h":82}
}
,{
	"filename": "Symbol 20 instance 10040",
	"frame": {"x":3600,"y":0,"w":90,"h":82},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":90,"h":82},
	"sourceSize": {"w":90,"h":82}
}
,{
	"filename": "Symbol 20 instance 10041",
	"frame": {"x":3690,"y":0,"w":90,"h":82},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":90,"h":82},
	"sourceSize": {"w":90,"h":82}
}
,{
	"filename": "Symbol 20 instance 10042",
	"frame": {"x":3780,"y":0,"w":90,"h":82},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":90,"h":82},
	"sourceSize": {"w":90,"h":82}
}
,{
	"filename": "Symbol 20 instance 10043",
	"frame": {"x":3870,"y":0,"w":90,"h":82},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":90,"h":82},
	"sourceSize": {"w":90,"h":82}
}
,{
	"filename": "Symbol 20 instance 10044",
	"frame": {"x":3960,"y":0,"w":90,"h":82},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":90,"h":82},
	"sourceSize": {"w":90,"h":82}
}
,{
	"filename": "Symbol 20 instance 10045",
	"frame": {"x":4050,"y":0,"w":90,"h":82},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":90,"h":82},
	"sourceSize": {"w":90,"h":82}
}
,{
	"filename": "Symbol 20 instance 10046",
	"frame": {"x":4140,"y":0,"w":90,"h":82},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":90,"h":82},
	"sourceSize": {"w":90,"h":82}
}
,{
	"filename": "Symbol 20 instance 10047",
	"frame": {"x":4230,"y":0,"w":90,"h":82},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":90,"h":82},
	"sourceSize": {"w":90,"h":82}
}
,{
	"filename": "Symbol 20 instance 10048",
	"frame": {"x":4320,"y":0,"w":90,"h":82},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":90,"h":82},
	"sourceSize": {"w":90,"h":82}
}
,{
	"filename": "Symbol 20 instance 10049",
	"frame": {"x":4410,"y":0,"w":90,"h":82},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":90,"h":82},
	"sourceSize": {"w":90,"h":82}
}],
"meta": {
	"app": "Adobe Animate",
	"version": "20.0.1.19255",
	"image": "fish bowl.png",
	"format": "RGBA8888",
	"size": {"w":4515,"h":89},
	"scale": "1"
}
},
/*storeManJson: {"frames": [

{
	"filename": "Symbol 14 instance 10000",
	"frame": {"x":0,"y":0,"w":172,"h":363},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":172,"h":363},
	"sourceSize": {"w":172,"h":363}
}
,{
	"filename": "Symbol 14 instance 10001",
	"frame": {"x":172,"y":0,"w":172,"h":363},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":172,"h":363},
	"sourceSize": {"w":172,"h":363}
}
,{
	"filename": "Symbol 14 instance 10002",
	"frame": {"x":344,"y":0,"w":172,"h":363},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":172,"h":363},
	"sourceSize": {"w":172,"h":363}
}
,{
	"filename": "Symbol 14 instance 10003",
	"frame": {"x":516,"y":0,"w":172,"h":363},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":172,"h":363},
	"sourceSize": {"w":172,"h":363}
}
,{
	"filename": "Symbol 14 instance 10004",
	"frame": {"x":688,"y":0,"w":172,"h":363},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":172,"h":363},
	"sourceSize": {"w":172,"h":363}
}
,{
	"filename": "Symbol 14 instance 10005",
	"frame": {"x":860,"y":0,"w":172,"h":363},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":172,"h":363},
	"sourceSize": {"w":172,"h":363}
}
,{
	"filename": "Symbol 14 instance 10006",
	"frame": {"x":1032,"y":0,"w":172,"h":363},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":172,"h":363},
	"sourceSize": {"w":172,"h":363}
}
,{
	"filename": "Symbol 14 instance 10007",
	"frame": {"x":1204,"y":0,"w":172,"h":363},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":172,"h":363},
	"sourceSize": {"w":172,"h":363}
}
,{
	"filename": "Symbol 14 instance 10008",
	"frame": {"x":1376,"y":0,"w":172,"h":363},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":172,"h":363},
	"sourceSize": {"w":172,"h":363}
}
,{
	"filename": "Symbol 14 instance 10009",
	"frame": {"x":1548,"y":0,"w":172,"h":363},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":172,"h":363},
	"sourceSize": {"w":172,"h":363}
}
,{
	"filename": "Symbol 14 instance 10010",
	"frame": {"x":1720,"y":0,"w":172,"h":363},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":172,"h":363},
	"sourceSize": {"w":172,"h":363}
}
,{
	"filename": "Symbol 14 instance 10011",
	"frame": {"x":1892,"y":0,"w":172,"h":363},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":172,"h":363},
	"sourceSize": {"w":172,"h":363}
}],
"meta": {
	"app": "Adobe Animate",
	"version": "20.0.1.19255",
	"image": "store man anim.png",
	"format": "RGBA8888",
	"size": {"w":2068,"h":384},
	"scale": "1"
}
},*/

boyGirlJson: {"frames": [

{
	"filename": "Symbol 13 instance 10000",
	"frame": {"x":0,"y":0,"w":264,"h":328},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":264,"h":328},
	"sourceSize": {"w":264,"h":328}
}
,{
	"filename": "Symbol 13 instance 10001",
	"frame": {"x":264,"y":0,"w":264,"h":328},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":264,"h":328},
	"sourceSize": {"w":264,"h":328}
}
,{
	"filename": "Symbol 13 instance 10002",
	"frame": {"x":528,"y":0,"w":264,"h":328},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":264,"h":328},
	"sourceSize": {"w":264,"h":328}
}
,{
	"filename": "Symbol 13 instance 10003",
	"frame": {"x":792,"y":0,"w":264,"h":328},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":264,"h":328},
	"sourceSize": {"w":264,"h":328}
}],
"meta": {
	"app": "Adobe Animate",
	"version": "20.0.1.19255",
	"image": "boy and girl.png",
	"format": "RGBA8888",
	"size": {"w":1067,"h":330},
	"scale": "1"
}
},
plusMinusZeroJson: {"frames": [

{
	"filename": "Symbol 12 instance 10000",
	"frame": {"x":0,"y":0,"w":40,"h":39},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":40,"h":39},
	"sourceSize": {"w":40,"h":39}
}
,{
	"filename": "Symbol 12 instance 10001",
	"frame": {"x":40,"y":0,"w":40,"h":39},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":40,"h":39},
	"sourceSize": {"w":40,"h":39}
}
,{
	"filename": "Symbol 12 instance 10002",
	"frame": {"x":80,"y":0,"w":40,"h":39},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":40,"h":39},
	"sourceSize": {"w":40,"h":39}
}],
"meta": {
	"app": "Adobe Animate",
	"version": "20.0.1.19255",
	"image": "Symbol +-O.png",
	"format": "RGBA8888",
	"size": {"w":128,"h":41},
	"scale": "1"
}
},

lightAppleJson: {"frames": [

{
	"filename": "Symbol 21 copy 2 instance 10000",
	"frame": {"x":0,"y":0,"w":31,"h":31},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":31,"h":31},
	"sourceSize": {"w":31,"h":31}
}
,{
	"filename": "Symbol 21 copy 2 instance 10001",
	"frame": {"x":31,"y":0,"w":31,"h":31},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":31,"h":31},
	"sourceSize": {"w":31,"h":31}
}
,{
	"filename": "Symbol 21 copy 2 instance 10002",
	"frame": {"x":62,"y":0,"w":31,"h":31},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":31,"h":31},
	"sourceSize": {"w":31,"h":31}
}],
"meta": {
	"app": "Adobe Animate",
	"version": "20.0.1.19255",
	"image": "Light apple anm 1.png",
	"format": "RGBA8888",
	"size": {"w":96,"h":37},
	"scale": "1"
}
},
appleJson: {"frames": [

{
	"filename": "Symbol 21 copy instance 10000",
	"frame": {"x":0,"y":0,"w":31,"h":31},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":31,"h":31},
	"sourceSize": {"w":31,"h":31}
}
,{
	"filename": "Symbol 21 copy instance 10001",
	"frame": {"x":31,"y":0,"w":31,"h":31},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":31,"h":31},
	"sourceSize": {"w":31,"h":31}
}
,{
	"filename": "Symbol 21 copy instance 10002",
	"frame": {"x":62,"y":0,"w":31,"h":31},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":31,"h":31},
	"sourceSize": {"w":31,"h":31}
}],
"meta": {
	"app": "Adobe Animate",
	"version": "20.0.1.19255",
	"image": "apple anm 1.png",
	"format": "RGBA8888",
	"size": {"w":96,"h":37},
	"scale": "1"
}
},
plusAppleJson: {"frames": [

{
	"filename": "Symbol 21 copy 3 instance 10000",
	"frame": {"x":0,"y":0,"w":30,"h":38},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":30,"h":38},
	"sourceSize": {"w":30,"h":38}
}
,{
	"filename": "Symbol 21 copy 3 instance 10001",
	"frame": {"x":30,"y":0,"w":30,"h":38},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":30,"h":38},
	"sourceSize": {"w":30,"h":38}
}
,{
	"filename": "Symbol 21 copy 3 instance 10002",
	"frame": {"x":60,"y":0,"w":30,"h":38},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":30,"h":38},
	"sourceSize": {"w":30,"h":38}
}
,{
	"filename": "Symbol 21 copy 3 instance 10003",
	"frame": {"x":90,"y":0,"w":30,"h":38},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":30,"h":38},
	"sourceSize": {"w":30,"h":38}
}
,{
	"filename": "Symbol 21 copy 3 instance 10004",
	"frame": {"x":120,"y":0,"w":30,"h":38},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":30,"h":38},
	"sourceSize": {"w":30,"h":38}
}
,{
	"filename": "Symbol 21 copy 3 instance 10005",
	"frame": {"x":150,"y":0,"w":30,"h":38},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":30,"h":38},
	"sourceSize": {"w":30,"h":38}
}
,{
	"filename": "Symbol 21 copy 3 instance 10006",
	"frame": {"x":180,"y":0,"w":30,"h":38},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":30,"h":38},
	"sourceSize": {"w":30,"h":38}
}
,{
	"filename": "Symbol 21 copy 3 instance 10007",
	"frame": {"x":210,"y":0,"w":30,"h":38},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":30,"h":38},
	"sourceSize": {"w":30,"h":38}
}
,{
	"filename": "Symbol 21 copy 3 instance 10008",
	"frame": {"x":240,"y":0,"w":30,"h":38},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":30,"h":38},
	"sourceSize": {"w":30,"h":38}
}
,{
	"filename": "Symbol 21 copy 3 instance 10009",
	"frame": {"x":270,"y":0,"w":30,"h":38},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":30,"h":38},
	"sourceSize": {"w":30,"h":38}
}
,{
	"filename": "Symbol 21 copy 3 instance 10010",
	"frame": {"x":300,"y":0,"w":30,"h":38},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":30,"h":38},
	"sourceSize": {"w":30,"h":38}
}
,{
	"filename": "Symbol 21 copy 3 instance 10011",
	"frame": {"x":330,"y":0,"w":30,"h":38},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":30,"h":38},
	"sourceSize": {"w":30,"h":38}
}
,{
	"filename": "Symbol 21 copy 3 instance 10012",
	"frame": {"x":360,"y":0,"w":30,"h":38},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":30,"h":38},
	"sourceSize": {"w":30,"h":38}
}
,{
	"filename": "Symbol 21 copy 3 instance 10013",
	"frame": {"x":390,"y":0,"w":30,"h":38},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":30,"h":38},
	"sourceSize": {"w":30,"h":38}
}
,{
	"filename": "Symbol 21 copy 3 instance 10014",
	"frame": {"x":420,"y":0,"w":30,"h":38},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":30,"h":38},
	"sourceSize": {"w":30,"h":38}
}
,{
	"filename": "Symbol 21 copy 3 instance 10015",
	"frame": {"x":450,"y":0,"w":30,"h":38},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":30,"h":38},
	"sourceSize": {"w":30,"h":38}
}
,{
	"filename": "Symbol 21 copy 3 instance 10016",
	"frame": {"x":480,"y":0,"w":30,"h":38},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":30,"h":38},
	"sourceSize": {"w":30,"h":38}
}
,{
	"filename": "Symbol 21 copy 3 instance 10017",
	"frame": {"x":510,"y":0,"w":30,"h":38},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":30,"h":38},
	"sourceSize": {"w":30,"h":38}
}
,{
	"filename": "Symbol 21 copy 3 instance 10018",
	"frame": {"x":540,"y":0,"w":30,"h":38},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":30,"h":38},
	"sourceSize": {"w":30,"h":38}
}],
"meta": {
	"app": "Adobe Animate",
	"version": "20.0.1.19255",
	"image": "apple anm +.png",
	"format": "RGBA8888",
	"size": {"w":577,"h":43},
	"scale": "1"
}
},
minusAppleJson : {"frames": [

{
	"filename": "Symbol 21 copy 4 instance 10000",
	"frame": {"x":0,"y":0,"w":28,"h":40},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":28,"h":40},
	"sourceSize": {"w":28,"h":40}
}
,{
	"filename": "Symbol 21 copy 4 instance 10001",
	"frame": {"x":28,"y":0,"w":28,"h":40},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":28,"h":40},
	"sourceSize": {"w":28,"h":40}
}
,{
	"filename": "Symbol 21 copy 4 instance 10002",
	"frame": {"x":56,"y":0,"w":28,"h":40},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":28,"h":40},
	"sourceSize": {"w":28,"h":40}
}
,{
	"filename": "Symbol 21 copy 4 instance 10003",
	"frame": {"x":84,"y":0,"w":28,"h":40},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":28,"h":40},
	"sourceSize": {"w":28,"h":40}
}
,{
	"filename": "Symbol 21 copy 4 instance 10004",
	"frame": {"x":112,"y":0,"w":28,"h":40},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":28,"h":40},
	"sourceSize": {"w":28,"h":40}
}
,{
	"filename": "Symbol 21 copy 4 instance 10005",
	"frame": {"x":140,"y":0,"w":28,"h":40},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":28,"h":40},
	"sourceSize": {"w":28,"h":40}
}
,{
	"filename": "Symbol 21 copy 4 instance 10006",
	"frame": {"x":168,"y":0,"w":28,"h":40},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":28,"h":40},
	"sourceSize": {"w":28,"h":40}
}
,{
	"filename": "Symbol 21 copy 4 instance 10007",
	"frame": {"x":196,"y":0,"w":28,"h":40},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":28,"h":40},
	"sourceSize": {"w":28,"h":40}
}
,{
	"filename": "Symbol 21 copy 4 instance 10008",
	"frame": {"x":224,"y":0,"w":28,"h":40},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":28,"h":40},
	"sourceSize": {"w":28,"h":40}
}
,{
	"filename": "Symbol 21 copy 4 instance 10009",
	"frame": {"x":252,"y":0,"w":28,"h":40},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":28,"h":40},
	"sourceSize": {"w":28,"h":40}
}
,{
	"filename": "Symbol 21 copy 4 instance 10010",
	"frame": {"x":280,"y":0,"w":28,"h":40},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":28,"h":40},
	"sourceSize": {"w":28,"h":40}
}
,{
	"filename": "Symbol 21 copy 4 instance 10011",
	"frame": {"x":308,"y":0,"w":28,"h":40},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":28,"h":40},
	"sourceSize": {"w":28,"h":40}
}
,{
	"filename": "Symbol 21 copy 4 instance 10012",
	"frame": {"x":336,"y":0,"w":28,"h":40},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":28,"h":40},
	"sourceSize": {"w":28,"h":40}
}
,{
	"filename": "Symbol 21 copy 4 instance 10013",
	"frame": {"x":364,"y":0,"w":28,"h":40},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":28,"h":40},
	"sourceSize": {"w":28,"h":40}
}
,{
	"filename": "Symbol 21 copy 4 instance 10014",
	"frame": {"x":392,"y":0,"w":28,"h":40},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":28,"h":40},
	"sourceSize": {"w":28,"h":40}
}
,{
	"filename": "Symbol 21 copy 4 instance 10015",
	"frame": {"x":420,"y":0,"w":28,"h":40},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":28,"h":40},
	"sourceSize": {"w":28,"h":40}
}
,{
	"filename": "Symbol 21 copy 4 instance 10016",
	"frame": {"x":448,"y":0,"w":28,"h":40},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":28,"h":40},
	"sourceSize": {"w":28,"h":40}
}
,{
	"filename": "Symbol 21 copy 4 instance 10017",
	"frame": {"x":476,"y":0,"w":28,"h":40},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":28,"h":40},
	"sourceSize": {"w":28,"h":40}
}
,{
	"filename": "Symbol 21 copy 4 instance 10018",
	"frame": {"x":504,"y":0,"w":28,"h":40},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":28,"h":40},
	"sourceSize": {"w":28,"h":40}
}],
"meta": {
	"app": "Adobe Animate",
	"version": "20.0.1.19255",
	"image": "apple anm -.png",
	"format": "RGBA8888",
	"size": {"w":541,"h":43},
	"scale": "1"
}
},

/*BellanimJson: {"frames": [

{
	"filename": "Symbol 36 instance 10000",
	"frame": {"x":0,"y":0,"w":39,"h":126},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":39,"h":126},
	"sourceSize": {"w":39,"h":126}
}
,{
	"filename": "Symbol 36 instance 10001",
	"frame": {"x":39,"y":0,"w":39,"h":126},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":39,"h":126},
	"sourceSize": {"w":39,"h":126}
}
,{
	"filename": "Symbol 36 instance 10002",
	"frame": {"x":78,"y":0,"w":39,"h":126},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":39,"h":126},
	"sourceSize": {"w":39,"h":126}
}
,{
	"filename": "Symbol 36 instance 10003",
	"frame": {"x":117,"y":0,"w":39,"h":126},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":39,"h":126},
	"sourceSize": {"w":39,"h":126}
}
,{
	"filename": "Symbol 36 instance 10004",
	"frame": {"x":156,"y":0,"w":39,"h":126},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":39,"h":126},
	"sourceSize": {"w":39,"h":126}
}
,{
	"filename": "Symbol 36 instance 10005",
	"frame": {"x":195,"y":0,"w":39,"h":126},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":39,"h":126},
	"sourceSize": {"w":39,"h":126}
}
,{
	"filename": "Symbol 36 instance 10006",
	"frame": {"x":234,"y":0,"w":39,"h":126},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":39,"h":126},
	"sourceSize": {"w":39,"h":126}
}
,{
	"filename": "Symbol 36 instance 10007",
	"frame": {"x":273,"y":0,"w":39,"h":126},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":39,"h":126},
	"sourceSize": {"w":39,"h":126}
}
,{
	"filename": "Symbol 36 instance 10008",
	"frame": {"x":312,"y":0,"w":39,"h":126},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":39,"h":126},
	"sourceSize": {"w":39,"h":126}
}
,{
	"filename": "Symbol 36 instance 10009",
	"frame": {"x":351,"y":0,"w":39,"h":126},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":39,"h":126},
	"sourceSize": {"w":39,"h":126}
}
,{
	"filename": "Symbol 36 instance 10010",
	"frame": {"x":390,"y":0,"w":39,"h":126},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":39,"h":126},
	"sourceSize": {"w":39,"h":126}
}
,{
	"filename": "Symbol 36 instance 10011",
	"frame": {"x":429,"y":0,"w":39,"h":126},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":39,"h":126},
	"sourceSize": {"w":39,"h":126}
}
,{
	"filename": "Symbol 36 instance 10012",
	"frame": {"x":468,"y":0,"w":39,"h":126},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":39,"h":126},
	"sourceSize": {"w":39,"h":126}
}],
"meta": {
	"app": "Adobe Animate",
	"version": "20.0.1.19255",
	"image": "Bell anim.png",
	"format": "RGBA8888",
	"size": {"w":509,"h":131},
	"scale": "1"
}
},*/



//integer two
rectangleBoxJson: {"frames": [

{
	"filename": "Symbol 1 instance 10000",
	"frame": {"x":0,"y":0,"w":868,"h":92},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":868,"h":92},
	"sourceSize": {"w":868,"h":92}
}
,{
	"filename": "Symbol 1 instance 10001",
	"frame": {"x":868,"y":0,"w":868,"h":92},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":868,"h":92},
	"sourceSize": {"w":868,"h":92}
}],
"meta": {
	"app": "Adobe Animate",
	"version": "20.0.1.19255",
	"image": "Rectangle box new.png",
	"format": "RGBA8888",
	"size": {"w":1739,"h":96},
	"scale": "1"
}
},
 questionAndAnswerBoxJson: {"frames": [

	{
		"filename": "Symbol 6 instance 10000",
		"frame": {"x":0,"y":0,"w":361,"h":100},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":361,"h":100},
		"sourceSize": {"w":361,"h":100}
	}
	,{
		"filename": "Symbol 6 instance 10001",
		"frame": {"x":361,"y":0,"w":361,"h":100},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":361,"h":100},
		"sourceSize": {"w":361,"h":100}
	}],
	"meta": {
		"app": "Adobe Animate",
		"version": "20.0.1.19255",
		"image": "Question and Aunser Box.png",
		"format": "RGBA8888",
		"size": {"w":732,"h":102},
		"scale": "1"
	}
	},
 squareBoxJson: {"frames": [

{
	"filename": "Symbol 1 instance 10000",
	"frame": {"x":0,"y":0,"w":98,"h":101},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":98,"h":101},
	"sourceSize": {"w":98,"h":101}
}
,{
	"filename": "Symbol 1 instance 10001",
	"frame": {"x":98,"y":0,"w":98,"h":101},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":98,"h":101},
	"sourceSize": {"w":98,"h":101}
}],
"meta": {
	"app": "Adobe Animate",
	"version": "20.0.1.19255",
	"image": "Square Box.png",
	"format": "RGBA8888",
	"size": {"w":204,"h":104},
	"scale": "1"
}
},
plusglowJson:{"frames": [

{
	"filename": "Symbol 7 copy instance 10000",
	"frame": {"x":0,"y":0,"w":57,"h":71},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":57,"h":71},
	"sourceSize": {"w":57,"h":71}
}
,{
	"filename": "Symbol 7 copy instance 10001",
	"frame": {"x":57,"y":0,"w":57,"h":71},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":57,"h":71},
	"sourceSize": {"w":57,"h":71}
}
,{
	"filename": "Symbol 7 copy instance 10002",
	"frame": {"x":114,"y":0,"w":57,"h":71},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":57,"h":71},
	"sourceSize": {"w":57,"h":71}
}],
"meta": {
	"app": "Adobe Animate",
	"version": "20.0.1.19255",
	"image": "+ Symbol.png",
	"format": "RGBA8888",
	"size": {"w":177,"h":72},
	"scale": "1"
}
},
minusglowJson: {"frames": [

{
	"filename": "Symbol 7 copy instance 10000",
	"frame": {"x":0,"y":0,"w":56,"h":71},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":56,"h":71},
	"sourceSize": {"w":56,"h":71}
}
,{
	"filename": "Symbol 7 copy instance 10001",
	"frame": {"x":56,"y":0,"w":56,"h":71},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":56,"h":71},
	"sourceSize": {"w":56,"h":71}
}
,{
	"filename": "Symbol 7 copy instance 10002",
	"frame": {"x":112,"y":0,"w":56,"h":71},
	"rotated": false,
	"trimmed": false,
	"spriteSourceSize": {"x":0,"y":0,"w":56,"h":71},
	"sourceSize": {"w":56,"h":71}
}],
"meta": {
	"app": "Adobe Animate",
	"version": "20.0.1.19255",
	"image": "- Symbol.png",
	"format": "RGBA8888",
	"size": {"w":169,"h":72},
	"scale": "1"
}
},

flipbtnJson:{"frames": [

	{
		"filename": "Symbol 2 instance 10000",
		"frame": {"x":0,"y":0,"w":98,"h":101},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":98,"h":101},
		"sourceSize": {"w":98,"h":101}
	}
	,{
		"filename": "Symbol 2 instance 10001",
		"frame": {"x":98,"y":0,"w":98,"h":101},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":98,"h":101},
		"sourceSize": {"w":98,"h":101}
	}
	,{
		"filename": "Symbol 2 instance 10002",
		"frame": {"x":196,"y":0,"w":98,"h":101},
		"rotated": false,
		"trimmed": false,
		"spriteSourceSize": {"x":0,"y":0,"w":98,"h":101},
		"sourceSize": {"w":98,"h":101}
	}],
	"meta": {
		"app": "Adobe Animate",
		"version": "20.0.1.19255",
		"image": "+ and -Box.png",
		"format": "RGBA8888",
		"size": {"w":300,"h":104},
		"scale": "1"
	}
	},
	
	minus_animationJson:{"frames":[

		{
			"filename": "Symbol 3 instance 10000",
			"frame": {"x":0,"y":0,"w":45,"h":68},
			"rotated": false,
			"trimmed": false,
			"spriteSourceSize": {"x":0,"y":0,"w":45,"h":68},
			"sourceSize": {"w":45,"h":68}
		}
		,{
			"filename": "Symbol 3 instance 10001",
			"frame": {"x":45,"y":0,"w":45,"h":68},
			"rotated": false,
			"trimmed": false,
			"spriteSourceSize": {"x":0,"y":0,"w":45,"h":68},
			"sourceSize": {"w":45,"h":68}
		}
		,{
			"filename": "Symbol 3 instance 10002",
			"frame": {"x":90,"y":0,"w":45,"h":68},
			"rotated": false,
			"trimmed": false,
			"spriteSourceSize": {"x":0,"y":0,"w":45,"h":68},
			"sourceSize": {"w":45,"h":68}
		}
		,{
			"filename": "Symbol 3 instance 10003",
			"frame": {"x":135,"y":0,"w":45,"h":68},
			"rotated": false,
			"trimmed": false,
			"spriteSourceSize": {"x":0,"y":0,"w":45,"h":68},
			"sourceSize": {"w":45,"h":68}
		}
		,{
			"filename": "Symbol 3 instance 10004",
			"frame": {"x":180,"y":0,"w":45,"h":68},
			"rotated": false,
			"trimmed": false,
			"spriteSourceSize": {"x":0,"y":0,"w":45,"h":68},
			"sourceSize": {"w":45,"h":68}
		}
		,{
			"filename": "Symbol 3 instance 10005",
			"frame": {"x":225,"y":0,"w":45,"h":68},
			"rotated": false,
			"trimmed": false,
			"spriteSourceSize": {"x":0,"y":0,"w":45,"h":68},
			"sourceSize": {"w":45,"h":68}
		}
		,{
			"filename": "Symbol 3 instance 10006",
			"frame": {"x":270,"y":0,"w":45,"h":68},
			"rotated": false,
			"trimmed": false,
			"spriteSourceSize": {"x":0,"y":0,"w":45,"h":68},
			"sourceSize": {"w":45,"h":68}
		}
		,{
			"filename": "Symbol 3 instance 10007",
			"frame": {"x":315,"y":0,"w":45,"h":68},
			"rotated": false,
			"trimmed": false,
			"spriteSourceSize": {"x":0,"y":0,"w":45,"h":68},
			"sourceSize": {"w":45,"h":68}
		}
		,{
			"filename": "Symbol 3 instance 10008",
			"frame": {"x":360,"y":0,"w":45,"h":68},
			"rotated": false,
			"trimmed": false,
			"spriteSourceSize": {"x":0,"y":0,"w":45,"h":68},
			"sourceSize": {"w":45,"h":68}
		}
		,{
			"filename": "Symbol 3 instance 10009",
			"frame": {"x":405,"y":0,"w":45,"h":68},
			"rotated": false,
			"trimmed": false,
			"spriteSourceSize": {"x":0,"y":0,"w":45,"h":68},
			"sourceSize": {"w":45,"h":68}
		}
		,{
			"filename": "Symbol 3 instance 10010",
			"frame": {"x":450,"y":0,"w":45,"h":68},
			"rotated": false,
			"trimmed": false,
			"spriteSourceSize": {"x":0,"y":0,"w":45,"h":68},
			"sourceSize": {"w":45,"h":68}
		}
		,{
			"filename": "Symbol 3 instance 10011",
			"frame": {"x":495,"y":0,"w":45,"h":68},
			"rotated": false,
			"trimmed": false,
			"spriteSourceSize": {"x":0,"y":0,"w":45,"h":68},
			"sourceSize": {"w":45,"h":68}
		}
		,{
			"filename": "Symbol 3 instance 10012",
			"frame": {"x":540,"y":0,"w":45,"h":68},
			"rotated": false,
			"trimmed": false,
			"spriteSourceSize": {"x":0,"y":0,"w":45,"h":68},
			"sourceSize": {"w":45,"h":68}
		}
		,{
			"filename": "Symbol 3 instance 10013",
			"frame": {"x":585,"y":0,"w":45,"h":68},
			"rotated": false,
			"trimmed": false,
			"spriteSourceSize": {"x":0,"y":0,"w":45,"h":68},
			"sourceSize": {"w":45,"h":68}
		}
		,{
			"filename": "Symbol 3 instance 10014",
			"frame": {"x":630,"y":0,"w":45,"h":68},
			"rotated": false,
			"trimmed": false,
			"spriteSourceSize": {"x":0,"y":0,"w":45,"h":68},
			"sourceSize": {"w":45,"h":68}
		}],
		"meta": {
			"app": "Adobe Animate",
			"version": "20.0.1.19255",
			"image": "- animation.png",
			"format": "RGBA8888",
			"size": {"w":677,"h":72},
			"scale": "1"
		}
		},


		plus_animationJson:{"frames": [

			{
				"filename": "Symbol 3 instance 10000",
				"frame": {"x":0,"y":0,"w":44,"h":68},
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": {"x":0,"y":0,"w":44,"h":68},
				"sourceSize": {"w":44,"h":68}
			}
			,{
				"filename": "Symbol 3 instance 10001",
				"frame": {"x":44,"y":0,"w":44,"h":68},
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": {"x":0,"y":0,"w":44,"h":68},
				"sourceSize": {"w":44,"h":68}
			}
			,{
				"filename": "Symbol 3 instance 10002",
				"frame": {"x":88,"y":0,"w":44,"h":68},
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": {"x":0,"y":0,"w":44,"h":68},
				"sourceSize": {"w":44,"h":68}
			}
			,{
				"filename": "Symbol 3 instance 10003",
				"frame": {"x":132,"y":0,"w":44,"h":68},
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": {"x":0,"y":0,"w":44,"h":68},
				"sourceSize": {"w":44,"h":68}
			}
			,{
				"filename": "Symbol 3 instance 10004",
				"frame": {"x":176,"y":0,"w":44,"h":68},
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": {"x":0,"y":0,"w":44,"h":68},
				"sourceSize": {"w":44,"h":68}
			}
			,{
				"filename": "Symbol 3 instance 10005",
				"frame": {"x":220,"y":0,"w":44,"h":68},
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": {"x":0,"y":0,"w":44,"h":68},
				"sourceSize": {"w":44,"h":68}
			}
			,{
				"filename": "Symbol 3 instance 10006",
				"frame": {"x":264,"y":0,"w":44,"h":68},
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": {"x":0,"y":0,"w":44,"h":68},
				"sourceSize": {"w":44,"h":68}
			}
			,{
				"filename": "Symbol 3 instance 10007",
				"frame": {"x":308,"y":0,"w":44,"h":68},
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": {"x":0,"y":0,"w":44,"h":68},
				"sourceSize": {"w":44,"h":68}
			}
			,{
				"filename": "Symbol 3 instance 10008",
				"frame": {"x":352,"y":0,"w":44,"h":68},
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": {"x":0,"y":0,"w":44,"h":68},
				"sourceSize": {"w":44,"h":68}
			}
			,{
				"filename": "Symbol 3 instance 10009",
				"frame": {"x":396,"y":0,"w":44,"h":68},
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": {"x":0,"y":0,"w":44,"h":68},
				"sourceSize": {"w":44,"h":68}
			}
			,{
				"filename": "Symbol 3 instance 10010",
				"frame": {"x":440,"y":0,"w":44,"h":68},
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": {"x":0,"y":0,"w":44,"h":68},
				"sourceSize": {"w":44,"h":68}
			}
			,{
				"filename": "Symbol 3 instance 10011",
				"frame": {"x":484,"y":0,"w":44,"h":68},
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": {"x":0,"y":0,"w":44,"h":68},
				"sourceSize": {"w":44,"h":68}
			}
			,{
				"filename": "Symbol 3 instance 10012",
				"frame": {"x":528,"y":0,"w":44,"h":68},
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": {"x":0,"y":0,"w":44,"h":68},
				"sourceSize": {"w":44,"h":68}
			}
			,{
				"filename": "Symbol 3 instance 10013",
				"frame": {"x":572,"y":0,"w":44,"h":68},
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": {"x":0,"y":0,"w":44,"h":68},
				"sourceSize": {"w":44,"h":68}
			}
			,{
				"filename": "Symbol 3 instance 10014",
				"frame": {"x":616,"y":0,"w":44,"h":68},
				"rotated": false,
				"trimmed": false,
				"spriteSourceSize": {"x":0,"y":0,"w":44,"h":68},
				"sourceSize": {"w":44,"h":68}
			}],
			"meta": {
				"app": "Adobe Animate",
				"version": "20.0.1.19255",
				"image": "+ animation.png",
				"format": "RGBA8888",
				"size": {"w":677,"h":72},
				"scale": "1"
			}
			},
};

